import { useState, type ReactNode } from "react";
import {
  ArrowUpRight,
  BarChart3,
  Bell,
  BriefcaseBusiness,
  Building2,
  CalendarDays,
  Check,
  ChevronDown,
  ChevronRight,
  CircleUserRound,
  Eye,
  FileCheck2,
  Globe2,
  LayoutDashboard,
  LockKeyhole,
  Menu,
  MessageCircle,
  PenLine,
  Plus,
  Rocket,
  Settings2,
  Share2,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  UserPlus,
  UsersRound,
  X,
} from "lucide-react";
import { Link, useLocation } from "react-router";

type NavItem = { label: string; path: string; Icon: typeof LayoutDashboard; count?: number };
type ProfileVisibility = "Public" | "Restricted" | "Private";

const navGroups: { label: string; items: NavItem[] }[] = [
  {
    label: "Manage",
    items: [
      { label: "Overview", path: "/organisations/alma-labs", Icon: LayoutDashboard },
      { label: "Profile", path: "/organisations/alma-labs/profile", Icon: Building2 },
      { label: "Credibility", path: "/organisations/alma-labs/credibility", Icon: ShieldCheck },
      { label: "Activity", path: "/organisations/alma-labs/activity", Icon: Sparkles },
    ],
  },
  {
    label: "Grow",
    items: [
      { label: "Investment", path: "/organisations/alma-labs/investment", Icon: TrendingUp, count: 1 },
      { label: "Jobs", path: "/organisations/alma-labs/jobs", Icon: BriefcaseBusiness, count: 3 },
      { label: "Statistics", path: "/organisations/alma-labs/statistics", Icon: BarChart3 },
    ],
  },
  {
    label: "People",
    items: [
      { label: "Team", path: "/organisations/alma-labs/team", Icon: UsersRound, count: 2 },
      { label: "Followers", path: "/organisations/alma-labs/followers", Icon: CircleUserRound },
    ],
  },
];

const activity = [
  { kind: "Update", title: "Why trusted company records matter", detail: "A short note from the Alma Labs team about making professional trust visible.", time: "Today", color: "bg-[var(--org-canvas)]" },
  { kind: "Event", title: "Lisbon Founder Supper", detail: "18 October · 18 guests · applications close in 4 days.", time: "Tomorrow", color: "bg-[#7c5cc4]" },
  { kind: "Milestone", title: "Verified profile reached 87 / 100", detail: "Certified accounts were reviewed and added to the public record.", time: "3 days ago", color: "bg-[#17191f]" },
];

function OrgMark({ dark = false }: { dark?: boolean }) {
  return <span className={`grid h-11 w-11 shrink-0 place-items-center font-serif text-lg font-black [clip-path:polygon(20%_0,80%_0,100%_20%,100%_80%,80%_100%,20%_100%,0_80%,0_20%)] ${dark ? "bg-[#17191f] text-white" : "bg-[var(--org-canvas)] text-[#17191f]"}`}>A</span>;
}

function OrganisationSelector({ compact = false }: { compact?: boolean }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className={`flex w-full items-center gap-3 text-left ${compact ? "text-white" : "border-b border-black/25 pb-5"}`}>
        <OrgMark dark={!compact} />
        <span className="min-w-0 flex-1">
          <b className="block truncate text-sm">Alma Labs</b>
          <span className={`mt-1 block text-[10px] font-bold ${compact ? "text-white/55" : "text-black/55"}`}>Credibility level 3 · 87</span>
        </span>
        <ChevronDown size={16} className={open ? "rotate-180" : ""} />
      </button>
      {open && (
        <div className={`absolute left-0 top-full z-50 mt-2 w-64 border-2 border-[#17191f] bg-white p-2 text-[#17191f] ${compact ? "left-auto right-0" : ""}`}>
          <button className="flex w-full items-center gap-3 bg-[var(--org-canvas)] p-3 text-left"><OrgMark dark /><span className="flex-1 text-xs font-bold">Alma Labs</span><Check size={15} /></button>
          <button className="mt-1 flex w-full items-center gap-3 p-3 text-left hover:bg-black/[.05]"><span className="grid h-8 w-8 place-items-center bg-[#17191f] text-xs font-black text-white">W</span><span className="flex-1 text-xs font-bold">WaveRent</span></button>
          <button className="mt-2 flex w-full items-center gap-2 border-t border-black/10 p-3 text-xs font-bold"><Plus size={14} /> Create new organisation</button>
        </div>
      )}
    </div>
  );
}

function PageHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col gap-5 border-b-2 border-[#17191f] pb-6 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <p className="text-[10px] font-black uppercase tracking-[.17em] text-black/50">{eyebrow}</p>
        <h1 className="mt-2 font-serif text-4xl font-black tracking-[-.05em]">{title}</h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-black/55">{description}</p>
      </div>
      {action}
    </div>
  );
}

function OverviewPage() {
  return (
    <>
      <div className="border-2 border-[#17191f] bg-[#17191f] p-6 text-white sm:p-8">
        <div className="flex flex-wrap items-start justify-between gap-5">
          <div className="flex items-start gap-4"><OrgMark /><div><p className="text-[10px] font-black uppercase tracking-[.17em] text-[var(--org-canvas)]">Operating organisation · 87 score</p><h1 className="mt-1 font-serif text-4xl font-black tracking-[-.05em]">Alma Labs</h1><p className="mt-2 text-sm text-white/60">Trusted organisation profiles for ambitious teams.</p></div></div>
          <span className="border border-white/25 px-3 py-2 text-xs font-bold">Level 3 · Verified</span>
        </div>
      </div>
      <div className="mt-5 grid gap-5 xl:grid-cols-[1.15fr_.85fr]">
        <section className="border-2 border-[#17191f] bg-white p-6"><div className="flex items-center justify-between"><div><p className="text-[10px] font-black uppercase tracking-[.16em]">Needs you</p><h2 className="mt-2 font-serif text-3xl font-black tracking-[-.04em]">One move, more proof.</h2></div><span className="grid h-10 w-10 place-items-center bg-[var(--org-canvas)]"><Rocket size={18} /></span></div><div className="mt-6 flex gap-4 border-t-2 border-black pt-4"><span className="grid h-10 w-10 shrink-0 place-items-center bg-[#17191f] text-white"><BarChart3 size={17} /></span><div className="flex-1"><b className="text-sm">Connect live traction</b><p className="mt-1 text-xs text-black/55">Connect Stripe to verify operating momentum.</p></div><button className="bg-[#17191f] px-4 text-xs font-black text-white">Connect</button></div></section>
        <section className="border-2 border-[#17191f] bg-[var(--org-canvas)] p-6"><p className="text-[10px] font-black uppercase tracking-[.16em]">Attention received · last 7 days</p><div className="mt-5 grid grid-cols-3 divide-x-2 divide-black">{[["12", "Views"], ["6", "Searches"], ["4", "Qualified"]].map(([value, label]) => <div key={label} className="px-3 first:pl-0"><b className="font-serif text-3xl">{value}</b><p className="mt-1 text-[9px] font-black uppercase tracking-[.12em]">{label}</p></div>)}</div><Link to="/organisations/alma-labs/statistics" className="mt-6 flex items-center justify-between border-t-2 border-black pt-3 text-xs font-black">Open statistics <ArrowUpRight size={14} /></Link></section>
      </div>
      <div className="mt-5 grid gap-5 lg:grid-cols-3">
        {[["Investment to confirm", "1", "A declared investment is waiting for your decision."], ["New applications", "3", "Three candidates applied to Product Lead."], ["Team links", "2", "Confirm two member relationships."]].map(([title, value, detail]) => <section key={title} className="border-2 border-[#17191f] bg-white p-5"><div className="flex items-start justify-between"><p className="text-xs font-bold">{title}</p><b className="grid h-7 w-7 place-items-center rounded-full bg-[#17191f] text-xs text-white">{value}</b></div><p className="mt-6 text-xs leading-5 text-black/55">{detail}</p><button className="mt-4 flex items-center gap-1 text-xs font-black">Review <ChevronRight size={14} /></button></section>)}
      </div>
    </>
  );
}

function ProfilePage() {
  const sections = [
    { title: "About", detail: "Mission, description, location and founding year.", preview: "Alma Labs builds trusted infrastructure for professional discovery.", fields: "6 fields", initialVisibility: "Public" },
    { title: "Product", detail: "Products, use cases, website and customer profile.", preview: "Verified organisation profiles and credibility signals.", fields: "8 fields", initialVisibility: "Public" },
    { title: "Market", detail: "Target market, positioning and expansion priorities.", preview: "Professional networks · Europe · B2B SaaS", fields: "5 fields", initialVisibility: "Restricted" },
    { title: "Traction & financials", detail: "Revenue range, growth, runway and operating metrics.", preview: "Updated September 2026 · 4 verified metrics", fields: "7 fields", initialVisibility: "Restricted" },
    { title: "Team", detail: "Members, roles and the people shown on the organisation record.", preview: "8 of 14 team members are visible.", fields: "14 people", initialVisibility: "Public" },
    { title: "Legal & contacts", detail: "Registered entity, address and primary contact details.", preview: "Accessible only to organisation owners.", fields: "9 fields", initialVisibility: "Private" },
  ] as const;
  const [visibility, setVisibility] = useState<Record<string, ProfileVisibility>>(
    Object.fromEntries(sections.map(section => [section.title, section.initialVisibility])) as Record<string, ProfileVisibility>,
  );
  const [filter, setFilter] = useState<"All" | ProfileVisibility>("All");
  const visibilityOptions: { label: ProfileVisibility; detail: string; Icon: typeof Globe2 }[] = [
    { label: "Public", detail: "Anyone can see it", Icon: Globe2 },
    { label: "Restricted", detail: "Approved groups only", Icon: UsersRound },
    { label: "Private", detail: "Workspace members only", Icon: LockKeyhole },
  ];
  const visibleSections = sections.filter(section => filter === "All" || visibility[section.title] === filter);
  const countFor = (audience: ProfileVisibility) => Object.values(visibility).filter(value => value === audience).length;
  return (
    <>
      <PageHeader eyebrow="Manage · Profile" title="Share with intention." description="Build one complete organisation record, then choose who can see each part of it." action={<Link target="_blank" to="/organisations/alma-labs/public" className="flex items-center gap-2 border-2 border-[#17191f] bg-white px-4 py-3 text-xs font-black">Preview public profile <ArrowUpRight size={14} /></Link>} />

      <section className="mt-6 border-2 border-[#17191f] bg-[#17191f] p-5 text-white sm:p-6">
        <div className="flex flex-col gap-6 xl:flex-row xl:items-end xl:justify-between">
          <div>
            <p className="text-[10px] font-black uppercase tracking-[.17em] text-[var(--org-canvas)]">Visibility architecture</p>
            <h2 className="mt-2 max-w-xl font-serif text-3xl font-black tracking-[-.04em]">One profile. Three levels of access.</h2>
            <p className="mt-3 max-w-xl text-xs leading-5 text-white/55">Information stays in one living record. Changing its audience never deletes the content or its verification history.</p>
          </div>
          <div className="grid gap-2 sm:grid-cols-3">
            {visibilityOptions.map(({ label, detail, Icon }) => (
              <button key={label} onClick={() => setFilter(filter === label ? "All" : label)} className={`flex min-w-40 items-center gap-3 border p-3 text-left transition ${filter === label ? "border-[var(--org-canvas)] bg-[var(--org-canvas)] text-[#17191f]" : "border-white/20 hover:border-white/50"}`}>
                <Icon size={17} />
                <span className="min-w-0 flex-1"><b className="block text-xs">{label} · {countFor(label)}</b><span className={`mt-1 block text-[10px] ${filter === label ? "text-black/55" : "text-white/45"}`}>{detail}</span></span>
              </button>
            ))}
          </div>
        </div>
      </section>

      <div className="mt-5 grid gap-5 xl:grid-cols-[minmax(0,1fr)_280px]">
        <div>
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-black uppercase tracking-[.16em] text-black/45">{filter === "All" ? "All profile sections" : `${filter} information`} · {visibleSections.length}</p>
            {filter !== "All" && <button onClick={() => setFilter("All")} className="text-xs font-black underline underline-offset-4">Show all</button>}
          </div>
          <div className="space-y-3">
            {visibleSections.map(section => {
              const current = visibility[section.title];
              const CurrentIcon = visibilityOptions.find(option => option.label === current)?.Icon ?? Eye;
              return (
                <section key={section.title} className="border-2 border-[#17191f] bg-white">
                  <div className="flex flex-col gap-5 p-5 sm:p-6">
                    <div className="flex flex-wrap items-start justify-between gap-4">
                      <div className="max-w-xl">
                        <div className="flex flex-wrap items-center gap-3">
                          <h2 className="font-serif text-2xl font-black">{section.title}</h2>
                          <span className={`flex items-center gap-1.5 border px-2.5 py-1 text-[9px] font-black uppercase tracking-[.1em] ${current === "Public" ? "border-black/25 bg-[var(--org-canvas)]" : current === "Restricted" ? "border-sky-500/40 bg-sky-50 text-sky-800" : "border-[#17191f] bg-[#17191f] text-white"}`}><CurrentIcon size={11} /> {current}</span>
                        </div>
                        <p className="mt-2 text-sm text-black/55">{section.detail}</p>
                        <p className="mt-4 border-l-2 border-black/20 pl-3 text-xs font-bold text-black/70">{section.preview}</p>
                      </div>
                      <button className="flex items-center gap-2 border-2 border-[#17191f] px-3 py-2.5 text-xs font-black"><PenLine size={13} /> Edit content</button>
                    </div>
                    <div className="flex flex-col gap-3 border-t border-black/10 pt-4 sm:flex-row sm:items-center">
                      <span className="text-[10px] font-black uppercase tracking-[.12em] text-black/40">{section.fields}</span>
                      <div className="flex flex-wrap gap-1 sm:ml-auto">
                        {visibilityOptions.map(({ label, Icon }) => (
                          <button key={label} onClick={() => setVisibility(currentVisibility => ({ ...currentVisibility, [section.title]: label }))} className={`flex items-center gap-1.5 border px-2.5 py-2 text-[10px] font-black transition ${current === label ? "border-[#17191f] bg-[#17191f] text-white" : "border-black/15 text-black/45 hover:border-black/45 hover:text-black"}`} aria-pressed={current === label}>
                            <Icon size={12} /> {label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </section>
              );
            })}
          </div>
        </div>

        <aside className="space-y-4">
          <section className="border-2 border-[#17191f] bg-white p-5">
            <div className="flex items-center justify-between"><UsersRound size={19} /><button className="grid h-8 w-8 place-items-center border border-black/20" aria-label="Create restricted group"><Plus size={14} /></button></div>
            <p className="mt-5 text-[10px] font-black uppercase tracking-[.16em] text-black/45">Restricted audiences</p>
            <h2 className="mt-2 font-serif text-2xl font-black">Share with the right room.</h2>
            <p className="mt-2 text-xs leading-5 text-black/50">Only approved people can access restricted profile sections.</p>
            <div className="mt-5 divide-y divide-black/10 border-y border-black/10">
              {[["Investor circle", "12 people"], ["Advisers & board", "6 people"]].map(([name, people]) => <button key={name} className="flex w-full items-center gap-3 py-4 text-left"><span className="grid h-8 w-8 place-items-center bg-sky-100 text-sky-800"><UsersRound size={14} /></span><span className="min-w-0 flex-1"><b className="block text-xs">{name}</b><span className="mt-1 block text-[10px] text-black/45">{people}</span></span><ChevronRight size={14} /></button>)}
            </div>
            <button className="mt-4 flex items-center gap-2 text-xs font-black"><Plus size={13} /> New restricted audience</button>
          </section>
          <section className="border-2 border-[#17191f] bg-[var(--org-canvas)] p-5">
            <LockKeyhole size={19} />
            <h2 className="mt-5 font-serif text-xl font-black">Private means internal.</h2>
            <p className="mt-2 text-xs leading-5 text-black/55">Private fields never appear in shared links or public previews. Workspace owners and authorised members can still maintain them.</p>
          </section>
        </aside>
      </div>
    </>
  );
}

function ActivityPage() {
  const [tab, setTab] = useState<"updates" | "events">("updates");
  return (
    <>
      <PageHeader eyebrow="Manage · Activity" title="Keep the record moving." description="Publish updates and manage events from one operational timeline." action={<button className="flex items-center gap-2 bg-[#17191f] px-4 py-3 text-xs font-black text-white"><Plus size={14} /> Create {tab === "updates" ? "update" : "event"}</button>} />
      <div className="mt-6 flex border-b-2 border-[#17191f]"><button onClick={() => setTab("updates")} className={`px-5 py-3 text-xs font-black ${tab === "updates" ? "bg-[#17191f] text-white" : "bg-white"}`}>Updates · 12</button><button onClick={() => setTab("events")} className={`px-5 py-3 text-xs font-black ${tab === "events" ? "bg-[#17191f] text-white" : "bg-white"}`}>Events · 2</button></div>
      <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_280px]">
        <div className="space-y-3">{(tab === "updates" ? activity.filter(item => item.kind !== "Event") : activity.filter(item => item.kind === "Event")).map(item => <article key={item.title} className="border-2 border-[#17191f] bg-white p-5"><div className="flex gap-4"><span className={`mt-1 h-3 w-3 shrink-0 ${item.color}`} /><div className="flex-1"><p className="text-[9px] font-black uppercase tracking-[.14em] text-black/40">{item.kind} · {item.time}</p><h2 className="mt-2 text-base font-bold">{item.title}</h2><p className="mt-2 text-xs leading-5 text-black/55">{item.detail}</p><div className="mt-4 flex gap-4 text-[10px] font-bold text-black/45"><span>482 views</span><span>24 reactions</span><span>6 shares</span></div></div><button><PenLine size={16} /></button></div></article>)}</div>
        <aside className="border-2 border-[#17191f] bg-[var(--org-canvas)] p-5"><CalendarDays size={20} /><h2 className="mt-4 font-serif text-2xl font-black">Next event.</h2><p className="mt-2 text-sm font-bold">Lisbon Founder Supper</p><p className="mt-2 text-xs leading-5 text-black/55">18 October · 19:00<br />Alma Labs, Lisbon</p><button className="mt-6 w-full bg-[#17191f] px-3 py-3 text-xs font-black text-white">Manage event</button></aside>
      </div>
    </>
  );
}

function TeamPage() {
  const members = [["Marta Pereira", "Co-founder & CEO", "Owner", "MP"], ["Joana Martins", "Product & Research", "Admin", "JM"], ["Inês Carvalho", "Advisory circle", "Member", "IC"], ["Rui Costa", "Engineering", "Member", "RC"]];
  return (
    <>
      <PageHeader eyebrow="People · Team" title="The people behind the record." description="Manage members, invitations, permissions and organisation links waiting for confirmation." action={<button className="flex items-center gap-2 bg-[#17191f] px-4 py-3 text-xs font-black text-white"><UserPlus size={14} /> Invite member</button>} />
      <section className="mt-6 border-2 border-[#17191f] bg-[var(--org-canvas)] p-5"><div className="flex items-center gap-3"><b className="grid h-8 w-8 place-items-center rounded-full bg-[#17191f] text-xs text-white">2</b><div><p className="text-sm font-bold">Relationships waiting for confirmation</p><p className="mt-1 text-xs text-black/55">Confirm that these people are linked to Alma Labs.</p></div><button className="ml-auto text-xs font-black underline">Review all</button></div></section>
      <section className="mt-4 border-2 border-[#17191f] bg-white"><div className="grid grid-cols-[1fr_auto] border-b-2 border-black p-4 text-[9px] font-black uppercase tracking-[.14em] text-black/45 sm:grid-cols-[1fr_180px_120px]"><span>Member</span><span className="hidden sm:block">Access</span><span>Status</span></div>{members.map(([name, role, access, initials]) => <div key={name} className="grid grid-cols-[1fr_auto] items-center gap-3 border-b border-black/10 p-4 last:border-0 sm:grid-cols-[1fr_180px_120px]"><div className="flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-full bg-[#17191f] text-[10px] font-black text-white">{initials}</span><div><b className="block text-sm">{name}</b><span className="text-xs text-black/45">{role}</span></div></div><span className="hidden text-xs sm:block">{access}</span><button className="flex items-center justify-end gap-1 text-xs font-bold">Active <ChevronDown size={13} /></button></div>)}</section>
    </>
  );
}

function SettingsPage() {
  const blocks = [
    ["Access & permissions", "Control who can edit, publish, invite and manage billing.", "4 roles configured", UsersRound],
    ["Plan & billing", "Manage your organisation plan, invoices and payment details.", "Beedero Pro", FileCheck2],
    ["Organisation details", "Legal name, registered address and primary contact.", "Last updated Sep 2026", Building2],
  ];
  return (
    <>
      <PageHeader eyebrow="Organisation · Settings" title="Control the workspace." description="Manage access, member permissions, billing and the organisation lifecycle." />
      <div className="mt-6 grid gap-4">{blocks.map(([title, detail, meta, Icon]) => { const SettingIcon = Icon as typeof UsersRound; return <button key={title as string} className="flex items-center gap-4 border-2 border-[#17191f] bg-white p-5 text-left"><span className="grid h-11 w-11 place-items-center bg-[var(--org-canvas)]"><SettingIcon size={19} /></span><span className="min-w-0 flex-1"><b className="block text-sm">{title as string}</b><span className="mt-1 block text-xs text-black/50">{detail as string}</span></span><span className="hidden text-xs font-bold text-black/45 sm:block">{meta as string}</span><ChevronRight size={17} /></button>; })}</div>
      <section className="mt-8 border-2 border-red-700 bg-white p-6"><p className="text-[10px] font-black uppercase tracking-[.16em] text-red-700">Danger zone</p><h2 className="mt-2 font-serif text-2xl font-black">Delete organisation</h2><p className="mt-2 text-xs leading-5 text-black/55">Permanently remove Alma Labs, its public record, activity and member access.</p><button className="mt-5 border-2 border-red-700 px-4 py-2.5 text-xs font-black text-red-700">Delete organisation</button></section>
    </>
  );
}

function GenericPage({ section }: { section: string }) {
  const content: Record<string, [string, string, string, typeof TrendingUp]> = {
    credibility: ["Credibility", "Build proof that compounds.", "Review verification levels, upload evidence and renew documents before they expire.", ShieldCheck],
    investment: ["Investment", "Run the round with clarity.", "Track your round, interested investors, declared investments and due diligence materials.", TrendingUp],
    jobs: ["Jobs", "Turn attention into talent.", "Manage job posts, new applications and renewals from one place.", BriefcaseBusiness],
    statistics: ["Statistics", "Understand who is paying attention.", "Explore profile views, followers, reach and the signals driving discovery.", BarChart3],
    followers: ["Followers", "The network around Alma Labs.", "See who follows the organisation and where relevant relationships are forming.", CircleUserRound],
  };
  const [title, headline, description, Icon] = content[section] ?? content.credibility;
  return (
    <>
      <PageHeader eyebrow={title} title={headline} description={description} />
      <div className="mt-6 grid gap-4 sm:grid-cols-3">{[["12", "Open signals"], ["4", "This month"], ["87", "Current score"]].map(([value, label], index) => <section key={label} className={`border-2 border-[#17191f] p-5 ${index === 0 ? "bg-[var(--org-canvas)]" : "bg-white"}`}><Icon size={18} /><b className="mt-6 block font-serif text-4xl">{value}</b><p className="mt-1 text-[10px] font-black uppercase tracking-[.13em] text-black/50">{label}</p></section>)}</div>
      <section className="mt-5 border-2 border-[#17191f] bg-white p-6"><h2 className="font-serif text-2xl font-black">Recent items</h2><div className="mt-5 divide-y divide-black/10">{["Review pending decision", "Record updated by Marta Pereira", "New signal received"].map((item, index) => <div key={item} className="flex items-center gap-3 py-4 first:pt-0"><span className="grid h-7 w-7 place-items-center bg-[#17191f] text-[10px] font-black text-white">{index + 1}</span><span className="flex-1 text-sm font-bold">{item}</span><span className="text-xs text-black/40">{index === 0 ? "Today" : `${index + 1} days ago`}</span><ChevronRight size={15} /></div>)}</div></section>
    </>
  );
}

function Sidebar({ currentPath, onNavigate }: { currentPath: string; onNavigate?: () => void }) {
  return (
    <div className="flex h-full min-h-0 flex-col">
      <OrganisationSelector />
      <nav className="org-sidebar-scroll -mr-2 mt-5 min-h-0 flex-1 overflow-y-auto pr-2">
        {navGroups.map(group => <div key={group.label} className="mb-5"><p className="mb-2 px-3 text-[9px] font-black uppercase tracking-[.17em] text-black/45">{group.label}</p>{group.items.map(({ label, path, Icon, count }) => { const active = currentPath === path; return <Link onClick={onNavigate} key={path} to={path} className={`flex items-center gap-3 px-3 py-2.5 text-sm transition ${active ? "bg-[#17191f] font-bold text-[var(--org-canvas)]" : "text-black/70 hover:bg-black/[.08] hover:text-black"}`}><Icon size={16} /><span className="flex-1">{label}</span>{count && <span className={`grid h-5 min-w-5 place-items-center rounded-full px-1 text-[10px] font-black ${active ? "bg-[var(--org-canvas)] text-black" : "bg-[#17191f] text-white"}`}>{count}</span>}</Link>; })}</div>)}
      </nav>
      <div className="border-t border-black/25 pt-4"><Link onClick={onNavigate} target="_blank" to="/organisations/alma-labs/public" className="flex items-center gap-3 px-3 py-2.5 text-sm font-bold"><Eye size={16} /><span className="flex-1">View public profile</span><ArrowUpRight size={14} /></Link><Link onClick={onNavigate} to="/organisations/alma-labs/settings" className="mt-1 flex items-center gap-3 px-3 py-2.5 text-sm font-bold"><Settings2 size={16} /><span className="flex-1">Settings</span></Link><Link to="/profile" className="mt-3 flex items-center gap-3 border-2 border-[#17191f] bg-white px-3 py-3 text-sm font-bold"><CircleUserRound size={17} /><span className="flex-1">Personal profile</span><ChevronRight size={15} /></Link></div>
    </div>
  );
}

export default function OrganisationProfile() {
  const { pathname } = useLocation();
  const [mobileMenu, setMobileMenu] = useState(false);
  const section = pathname.split("/")[3] ?? "overview";
  let page: ReactNode = <OverviewPage />;
  if (section === "profile") page = <ProfilePage />;
  else if (section === "activity") page = <ActivityPage />;
  else if (section === "team") page = <TeamPage />;
  else if (section === "settings") page = <SettingsPage />;
  else if (section !== "overview") page = <GenericPage section={section} />;

  return (
    <main className="min-h-screen bg-[var(--org-canvas)] font-sans text-[#15161a]">
      <header className="sticky top-0 z-40 border-b-2 border-[var(--org-ink)] bg-[var(--org-ink)] text-white">
        <div className="mx-auto flex min-h-[70px] max-w-[1500px] items-center gap-4 px-4 sm:px-6">
          <Link to="/app" className="text-xl font-black uppercase tracking-[-.055em] text-[var(--org-canvas)]">beedero.</Link>
          <span className="hidden h-5 w-px bg-white/25 lg:block" /><span className="hidden text-[10px] font-black uppercase tracking-[.18em] text-white/50 lg:block">Organisation workspace</span>
          <div className="ml-auto hidden items-center gap-2 sm:flex"><Link target="_blank" to="/organisations/alma-labs/public" className="flex items-center gap-2 border border-white/30 px-3 py-2 text-xs font-bold"><Eye size={14} /> Public profile</Link><button className="flex items-center gap-2 bg-[var(--org-canvas)] px-3 py-2 text-xs font-black text-[#17191f]"><Share2 size={14} /> Share</button><Link to="/messages" aria-label="Organisation messages" className="relative grid h-9 w-9 place-items-center border border-white/30"><MessageCircle size={16} /><span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-[var(--org-canvas)] text-[9px] font-black text-black">2</span></Link><button className="relative grid h-9 w-9 place-items-center border border-white/30"><Bell size={16} /><span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-[var(--org-canvas)] text-[9px] font-black text-black">3</span></button></div>
          <button onClick={() => setMobileMenu(!mobileMenu)} className="ml-auto grid h-10 w-10 place-items-center border border-white/30 lg:hidden" aria-label="Toggle organisation menu">{mobileMenu ? <X size={19} /> : <Menu size={19} />}</button>
        </div>
        <div className="border-t border-white/15 p-3 lg:hidden"><OrganisationSelector compact /></div>
      </header>
      {mobileMenu && <div className="fixed inset-x-0 bottom-0 top-[137px] z-30 overflow-y-auto bg-[var(--org-canvas)] p-4 lg:hidden"><Sidebar currentPath={pathname} onNavigate={() => setMobileMenu(false)} /></div>}
      <div className="mx-auto grid max-w-[1500px] lg:grid-cols-[252px_minmax(0,1fr)]">
        <aside className="hidden border-r-2 border-[var(--org-ink)] bg-[var(--org-rail)] p-5 lg:sticky lg:top-[70px] lg:block lg:h-[calc(100vh-70px)]"><Sidebar currentPath={pathname} /></aside>
        <section className="min-w-0 p-4 sm:p-6 lg:p-8">{page}</section>
      </div>
    </main>
  );
}

export function OrganisationPublicProfile() {
  return (
    <main className="min-h-screen bg-[var(--org-canvas)] font-sans text-[#17191f]">
      <header className="border-b-2 border-[#17191f]"><div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5"><Link to="/" className="text-xl font-black uppercase tracking-[-.055em]">beedero.</Link><div className="flex items-center gap-3"><span className="hidden text-xs font-bold text-black/50 sm:block">Verified organisation record</span><button className="bg-[#17191f] px-4 py-2.5 text-xs font-black text-white">Follow Alma Labs</button></div></div></header>
      <section className="mx-auto max-w-6xl px-5 py-12 sm:py-20">
        <div className="grid gap-10 lg:grid-cols-[1fr_320px] lg:items-end"><div><div className="flex items-center gap-4"><OrgMark dark /><span className="border border-black/30 px-3 py-1.5 text-[10px] font-black uppercase tracking-[.14em]">Credibility level 3 · 87</span></div><h1 className="mt-8 max-w-4xl font-serif text-6xl font-black tracking-[-.065em] sm:text-8xl">Trust should be visible.</h1><p className="mt-6 max-w-2xl text-lg leading-8 text-black/60">Alma Labs builds a clearer, more trusted way for ambitious organisations and people to discover each other.</p></div><div className="border-2 border-[#17191f] bg-[var(--org-canvas)] p-6"><p className="text-[10px] font-black uppercase tracking-[.16em]">Organisation details</p><div className="mt-5 space-y-3 text-sm"><p><b>Lisbon, Portugal</b></p><p>Software · Seed stage</p><p>Founded in 2022</p><p>14 team members</p></div><button className="mt-6 flex w-full items-center justify-between bg-[#17191f] px-4 py-3 text-xs font-black text-white">Visit website <ArrowUpRight size={14} /></button></div></div>
        <div className="mt-16 grid gap-5 md:grid-cols-3"><section className="border-2 border-[#17191f] bg-white p-6 md:col-span-2"><p className="text-[10px] font-black uppercase tracking-[.16em]">About</p><h2 className="mt-3 font-serif text-3xl font-black">Professional trust, built as infrastructure.</h2><p className="mt-5 max-w-2xl text-sm leading-7 text-black/60">We turn scattered company information into living, verified records. Teams can show the work, proof and people behind their progress before the first meeting.</p></section><section className="border-2 border-[#17191f] bg-[#17191f] p-6 text-white"><ShieldCheck className="text-[var(--org-canvas)]" /><h2 className="mt-5 font-serif text-2xl font-black">3 / 4 verified</h2><p className="mt-2 text-xs leading-5 text-white/55">Legal identity, compliance and certified accounts confirmed.</p></section></div>
        <section className="mt-5 border-2 border-[#17191f] bg-white p-6 sm:p-8"><div className="flex items-end justify-between"><div><p className="text-[10px] font-black uppercase tracking-[.16em]">Latest activity</p><h2 className="mt-2 font-serif text-3xl font-black">Signals from Alma Labs.</h2></div><Sparkles size={21} /></div><div className="mt-6 grid gap-3 md:grid-cols-3">{activity.map(item => <article key={item.title} className="border border-black/20 p-4"><span className={`block h-2 w-8 ${item.color}`} /><p className="mt-4 text-[9px] font-black uppercase tracking-[.14em] text-black/40">{item.kind}</p><h3 className="mt-2 text-sm font-bold">{item.title}</h3><p className="mt-2 text-xs leading-5 text-black/50">{item.detail}</p></article>)}</div></section>
      </section>
    </main>
  );
}

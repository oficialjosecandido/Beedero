import { Globe2, LockKeyhole, UsersRound } from "lucide-react";
import { Link, useParams } from "react-router";
import AppShell from "./AppShell";

const publicExperience = [
  ["Work", "Co-founder & CEO", "Alma Labs", "2022 — Present", "Building a clearer, more trusted way for ambitious organisations to be discovered."],
  ["Project", "Atlas research", "Independent", "2023", "A field study into how verified signals compound professional trust."],
  ["Academic", "MSc, Management", "Nova SBE", "2016 — 2018", "Strategy, organisational behaviour and entrepreneurship."],
];

function Preview({ restricted = false }: { restricted?: boolean }) {
  const { group } = useParams();
  const groupName = group ? decodeURIComponent(group).replace(/-/g, " ") : "Restricted group 1";
  const experiences = restricted ? [...publicExperience, ["Investment", "Angel investor", "Operator Syndicate", "2021 — Present", "Backing early teams working on durable tools for real-world work."]] : publicExperience;
  return <AppShell><div className="mx-auto max-w-4xl"><div className="flex flex-wrap items-center justify-between gap-3"><Link to="/profile" className="text-xs font-bold text-[#f9de4a]">← Back to my profile</Link><span className={`flex items-center gap-2 border px-3 py-1.5 text-[10px] font-black uppercase tracking-[.14em] ${restricted ? "border-sky-300/50 text-sky-300" : "border-[#f9de4a]/50 text-[#f9de4a]"}`}>{restricted ? <UsersRound size={13} /> : <Globe2 size={13} />}{restricted ? `Restricted · ${groupName}` : "Public profile"}</span></div><section className="mt-5 border border-white/10 bg-white/[.025] p-6 sm:p-9"><div className="flex items-start gap-4"><span className="grid h-16 w-16 place-items-center rounded-full bg-[#68738a] text-xl font-black">MP</span><div><h1 className="font-serif text-4xl font-black tracking-[-.055em]">Marta Pereira</h1><p className="mt-2 text-base text-white/65">Co-founder at Alma Labs</p><p className="mt-1 text-sm text-white/40">Lisbon, Portugal · almalabs.pt</p></div></div><p className="mt-7 max-w-2xl border-l-2 border-[#f9de4a] pl-4 text-sm leading-6 text-white/65">Building more useful, trusted ways for people and organisations to connect.</p></section><section className="mt-5 border border-white/10 bg-white/[.025] p-6 sm:p-9"><div className="flex items-center justify-between"><div><p className="text-[10px] font-black uppercase tracking-[.18em] text-[#f9de4a]">Professional record</p><h2 className="mt-2 font-serif text-3xl font-black">Experience.</h2></div>{restricted && <span className="flex items-center gap-1.5 text-xs text-sky-300"><LockKeyhole size={13} /> Shared with your group</span>}</div><div className="mt-7 space-y-0">{experiences.map(([type, title, organisation, period, detail]) => <article key={title} className="grid grid-cols-[24px_1fr] gap-4 border-b border-white/[.08] py-6 first:pt-0 last:border-0 last:pb-0"><span className="mt-1 h-3 w-3 rounded-full bg-[#f9de4a]" /><div><p className="text-[10px] font-black uppercase tracking-[.14em] text-white/35">{type} · {period}</p><h3 className="mt-1 text-base font-bold">{title}</h3><p className="mt-1 text-sm text-white/55">{organisation}</p><p className="mt-3 text-sm leading-6 text-white/60">{detail}</p></div></article>)}</div></section></div></AppShell>;
}

export function PublicProfilePreview() { return <Preview />; }
export function RestrictedProfilePreview() { return <Preview restricted />; }

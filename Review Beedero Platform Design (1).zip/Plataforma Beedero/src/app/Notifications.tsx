import { BellDot, CheckCheck, ChevronRight, Settings2, X } from "lucide-react";
import { Link } from "react-router";
import { useEffect, useRef, useState } from "react";
import AppShell from "./AppShell";

type Note = { id: string; text: string; detail: string; time: string; urgent: boolean; to: string; unread: boolean };

const initialNotes: Note[] = [
  { id: "ines", text: "Inês Carvalho accepted your connection.", detail: "You can now message each other directly.", time: "2m ago", urgent: false, to: "/profile/ines-carvalho", unread: true },
  { id: "alma", text: "Alma Labs appeared in 6 searches this week.", detail: "See what is driving visibility in your organisation KPIs.", time: "1h ago", urgent: false, to: "/organisations/alma-labs/kpis", unread: true },
  { id: "compliance", text: "Your compliance verification expires in 30 days.", detail: "Review the requirements before your verification lapses.", time: "3h ago", urgent: true, to: "/profile/settings", unread: true },
];

const olderNotes = [
  { text: "Joana Martins shared an update from Rooted.", detail: "A new post is waiting in your network feed.", time: "Yesterday", urgent: false, to: "/app" },
  { text: "Your profile appeared in 3 relevant searches.", detail: "See which parts of your record are helping you get discovered.", time: "Yesterday", urgent: false, to: "/profile" },
  { text: "Alma Labs gained a new follower.", detail: "Your organisation record is reaching the right people.", time: "2 days ago", urgent: false, to: "/organisations/alma-labs/kpis" },
];

export default function Notifications() {
  const [notes, setNotes] = useState(initialNotes);
  const [preferencesOpen, setPreferencesOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [preferences, setPreferences] = useState({ connections: true, organisation: true, compliance: true, email: false });
  const sentinelRef = useRef<HTMLDivElement>(null);
  const unreadCount = notes.filter(note => note.unread).length;
  const togglePreference = (key: keyof typeof preferences) => setPreferences(current => ({ ...current, [key]: !current[key] }));

  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting || loading) return;
      setLoading(true);
      window.setTimeout(() => {
        const batchId = Date.now();
        setNotes(current => [...current, ...olderNotes.map((note, index) => ({ ...note, id: `${batchId}-${index}`, unread: false }))]);
        setLoading(false);
      }, 500);
    }, { rootMargin: "180px" });
    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [loading]);

  return (
    <AppShell>
      <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#f9de4a]">Keep the right pulse</p>
      <div className="mt-2 mb-8 flex flex-wrap items-end justify-between gap-4"><h1 className="font-serif text-4xl font-black tracking-[-.045em]">Notifications.</h1><div className="flex flex-wrap gap-2"><button onClick={() => setNotes(current => current.map(note => ({ ...note, unread: false })))} disabled={unreadCount === 0} className="flex items-center gap-2 border border-[#f9de4a]/60 px-4 py-2.5 text-xs font-bold text-[#f9de4a] transition hover:bg-[#f9de4a] hover:text-black disabled:cursor-default disabled:opacity-40"><CheckCheck size={15} /> Mark all as read{unreadCount > 0 && ` (${unreadCount})`}</button><button onClick={() => setPreferencesOpen(true)} className="flex items-center gap-2 border border-white/15 px-4 py-2.5 text-xs font-bold text-white/70 transition hover:border-[#f9de4a] hover:text-[#f9de4a]"><Settings2 size={15} /> Preferences</button></div></div>
      <div className="max-w-4xl divide-y divide-white/10 border-y border-white/10">
        {notes.map(note => <Link onClick={() => setNotes(current => current.map(item => item.id === note.id ? { ...item, unread: false } : item))} to={note.to} className={`group relative flex gap-4 px-4 py-5 transition hover:bg-white/[.025] sm:px-5 ${note.unread ? "bg-white/[.025]" : ""}`} key={note.id}><>{note.unread && <span className="absolute inset-y-4 left-0 w-0.5 bg-[#f9de4a]" />}</><BellDot className={`mt-0.5 shrink-0 ${note.urgent ? "text-[#f9de4a]" : "text-white/40"}`} size={18} /><div className="flex-1"><p className={`text-sm leading-6 ${note.unread ? "font-semibold text-white" : "text-white/75"}`}>{note.text}</p><p className="mt-1 text-xs leading-5 text-white/45">{note.detail}</p><small className="mt-2 block text-[11px] text-white/35">{note.time}</small></div><ChevronRight className="mt-1 text-white/25 transition group-hover:translate-x-0.5 group-hover:text-[#f9de4a]" size={17} /></Link>)}
      </div>
      <div ref={sentinelRef} className="flex h-20 items-center justify-center text-xs text-white/40">{loading ? <span className="flex items-center gap-2"><i className="h-3 w-3 animate-spin rounded-full border-2 border-white/20 border-t-[#f9de4a]" /> Loading more notifications</span> : "Scroll for more"}</div>

      {preferencesOpen && <div className="fixed inset-0 z-50 grid place-items-end bg-black/70 p-0 backdrop-blur-sm sm:place-items-center sm:p-6" onClick={event => { if (event.target === event.currentTarget) setPreferencesOpen(false); }}><section className="w-full max-w-md border border-white/15 bg-[#171a20] shadow-2xl"><header className="flex items-center justify-between border-b border-white/10 px-6 py-5"><div><div className="flex items-center gap-2"><Settings2 size={16} className="text-[#f9de4a]" /><h2 className="font-serif text-2xl font-black">Notification preferences</h2></div><p className="mt-1 text-xs text-white/45">Choose the signals that deserve your attention.</p></div><button onClick={() => setPreferencesOpen(false)} className="text-white/45 hover:text-white" aria-label="Close preferences"><X size={19} /></button></header><div className="divide-y divide-white/[.08] px-6">{[["connections", "Connections", "Accepted requests and relationship activity"], ["organisation", "Organisation insights", "Alma Labs visibility and KPI changes"], ["compliance", "Compliance", "Verification and deadline reminders"], ["email", "Email digest", "A daily recap when you are away"] as const].map(([key, label, detail]) => <button key={key} onClick={() => togglePreference(key)} className="flex w-full items-center gap-3 py-4 text-left"><span className={`relative h-5 w-9 rounded-full transition ${preferences[key] ? "bg-[#f9de4a]" : "bg-white/15"}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full transition ${preferences[key] ? "left-4 bg-black" : "left-0.5 bg-white/70"}`} /></span><span className="min-w-0 flex-1"><b className="block text-xs">{label}</b><small className="mt-0.5 block leading-4 text-[10px] text-white/40">{detail}</small></span></button>)}</div><footer className="flex justify-end border-t border-white/10 px-6 py-4"><button onClick={() => setPreferencesOpen(false)} className="bg-[#f9de4a] px-4 py-2.5 text-xs font-black text-black">Save preferences</button></footer></section></div>}
    </AppShell>
  );
}

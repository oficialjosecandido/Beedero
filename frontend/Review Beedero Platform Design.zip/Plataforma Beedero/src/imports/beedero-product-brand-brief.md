# Beedero — Product & Brand Brief (for design / wireframes)

**Purpose of this document:** a complete brief describing what Beedero is, its mission, brand, visual identity, current features, and roadmap — to feed into Figma Make (or any design tool) to generate wireframes and UI.

---

## 1. What Beedero Is (in one line)

> **Beedero is the verified network for startups and investors — the verified record of a company's life.**

Think "LinkedIn for startups," but where traction, team, and credibility are **verified, not self-declared**. A startup builds a structured, verifiable profile once and reuses it anywhere — for an investor, a bank, a client, or a partner. Useful from day one, whether or not they're raising.

**One-line pitch:** *In a world full of noise, verified beats loud.*

---

## 2. The Problem We Solve

In the startup world, a company's progress, team, and credibility are **scattered across a dozen places and mostly self-declared**. Anyone can claim "€8M raised" or "10x growth." The signal is broken:
- **Investors** waste time on due diligence and can't quickly tell who's credible.
- **Founders** who are honest get lost in the noise.
- Existing networks (LinkedIn, etc.) optimise for **reach and vanity metrics**, not verified truth.

There is no infrastructure that **proves a company is real** and shows its **verified traction**.

---

## 3. What We Do (the solution)

Beedero verifies companies across **four layers**, so credibility is earned, not typed:
1. **Legal identity** — company registry certificate + tax number.
2. **Compliance** — tax & social security standing.
3. **Certified accounts** — financials signed off by a certified accountant.
4. **Real-time traction** — live metrics (e.g. via Stripe).

Founders control **exactly who sees what, field by field** (public / connections / restricted / private), enforced at the database level. Investors get **trustworthy deal flow** with a private pipeline. Both sides are **free**.

**The moat:** granular field-level privacy + verified credibility + local density (Portugal → Iberia → Southern Europe). No competitor combines all three.

---

## 4. Mission, Vision & Values

**Mission:** To make **trust** the foundation of the startup ecosystem — giving every company a verified record of its life: proof it's real, ready whenever it's needed.

**Vision:** A world where a startup's real progress is its professional identity — where credibility is proven, not claimed, and where founders and investors connect on truth, not noise.

**Values:**
- **Verified over declared** — facts, not claims. The entire product is built on this.
- **Trust is the product** — every decision protects user confidence and data.
- **Privacy by design** — users own their data and control who sees what.
- **Quality over vanity** — no likes, no follower-count popularity contests; credibility is the signal.
- **Value that compounds** — the profile is an asset that grows over time, not a treadmill of engagement.
- **No middleman** — Beedero never touches investment money; it records and verifies, it does not intermediate.
- **Contact by relationship** — no unsolicited messages; connection is mutual.

---

## 5. Objectives

- **Short term:** launch in Portugal, hand-recruit the first ~30 investors and ~15 verified startups, prove liquidity in one market.
- **Medium term:** density in Portugal → expand across Iberia and Southern Europe; turn on first monetisation (Founder Pro during fundraising).
- **Long term:** become the trusted verified layer of the European startup ecosystem — the place a startup's verified record lives.

---

## 6. Brand & Identity

**Name:** Beedero (bee → honeycomb → hive → network of connected nodes).

**Brand personality:** trustworthy, credible, sober, confident. **Not** hype-y, not a flashy consumer app, not a dating app. It should feel **solid and reliable** — because the product is trust. Professional but human; clear, not corporate-cold.

**Tone of voice:**
- Direct, confident, no empty buzzwords.
- Fact + meaning (e.g. "2 investors viewed your profile" + "your record is gaining the right attention").
- Honest and understated. Speaks with respect, never with dating-app hype.
- Signature line: *"verified beats loud."*

**Symbol:** a **hexagon (honeycomb) with a bee** — the verification seal motif. Hexagons connected by lines = the network/community.

---

## 7. Visual Identity

**Colours:**
- **Primary — Honey yellow / gold:** `#f5c542` → `#e8a11c` (gradient). The signature Beedero colour.
- **Dark background:** `#1a1d24` / `#22252e`. Dark-first (fintech/trust aesthetic; the gold pops on dark).
- **Text on dark:** white `#ffffff` (headlines), light grey `#c9ccd2` / `#b9bcc4` (body), muted grey `#8a8d95` (captions).
- **Accent / semantic:** green for verified/success, amber for warning/expiring, red used sparingly.

**Typography:**
- **Wordmark / display:** a serif for the "beedero" wordmark (elegant, trustworthy — think Georgia-style serif).
- **UI / body:** a clean sans-serif (Arial/Helvetica/Inter family) for everything functional.
- Strong hierarchy: large bold headlines, lighter supporting text. Let information breathe (generous whitespace).

**Iconography & shapes:**
- Hexagons/honeycomb as a recurring motif (verification, network nodes).
- Rounded corners on cards and buttons; pill-shaped CTAs.
- Clean line icons (checkmark in circle for verified, briefcase for jobs, etc.).

**Design principles (2026-aligned):**
- **Bento-grid layouts** for dashboards (modular cards, information-dense but not overwhelming).
- **Skeleton screens** on load (not spinners).
- **Functional motion** only (transitions that explain, never decorative); respect `prefers-reduced-motion`.
- **Mobile-first & responsive** (a PWA exists; many journeys start on phone).
- **Accessibility:** WCAG contrast (min 4.5:1), keyboard navigation, semantic HTML, tap targets ≥44px.
- **Avoid:** brutalism, heavy 3D, glassmorphism, vanity metrics, anything that reads "unfinished" or "hype."

**Visual metaphor to convey:** a network of verified, connected nodes — trust made visible. The profile timeline is the hero UI piece (a verified record growing over time).

---

## 8. Who It's For (the stakeholders)

- **Founders / startups** (the anchor): build a verified profile, get discovered, raise, hire.
- **Investors** (the scarce side): trustworthy deal flow, private pipeline, verified startups.
- **Talent / job seekers:** find roles at verified startups (jobs board).
- **Co-founders:** find a co-founder (verified, local).
- **Advisors:** verified advisory track record.

**Core principle across all:** people are **label-free**. A person is one identity (node); roles ("founder," "investor," "advisor") live in their *relationships* to organizations, not as labels stuck on the person. A person doesn't *have* a type; they *have* verified affiliations and optional capabilities.

---

## 9. Current Features (built / live)

**Profiles & identity**
- **Organization profiles** — sections with field-level visibility (About, Team, Products, Market thesis, Fundraising, etc.).
- **Personal profiles** (`/p/<handle>`) — the person as a single identity; brand/expression layer (bio, manifesto, links, free-form skills up to 30) + verified layer (credibility, affiliations timeline).
- **Verified affiliations** — a person's roles at organizations, over time, with verification (company confirms employment; founder verified via registry certificate). Overlapping, time-based roles shown as a **timeline / Gantt**.
- **Public shareable profile** with Open Graph + an **embeddable "verified" badge** (links to the public profile, reflects live status).

**Credibility (the moat)**
- **4-layer credibility ladder** (identity → compliance → certified accounts → traction). Verification expires (keeps the seal honest).
- **Manual verification backoffice** (admin reviews registry certificate; one review verifies company + founders).

**Network & feed**
- **Two separate graphs:** Follow (attention → feed, one-directional) and **Connections** (trust → visibility + messaging, mutual). Never merged.
- **Feed** with posts, field-level visibility.
- **Posts by type:** Update, Milestone, Event (orgs get all three; people get Update + Milestone). One post/day limit (quality). Future events highlighted.
- **Messaging** — no "message requests" black hole. First contact is a **connection-request-with-a-note**; accepting opens the conversation. Block & report built in.
- **Rich link previews** (unfurl) and **@mentions**.

**Engagement & value**
- **Notifications** (in-app + email) with aggregation and preferences; single emitter.
- **Weekly digest**.
- **Dashboard with KPIs & deltas** (profile views, followers, reach) — no vanity likes.
- **Milestones** with shareable cards.

**Investor tools**
- **Private investor pipeline** (`watching → reviewing → meeting → diligence → passed → invested`) — private to the investor, founders never see it.
- **Investor match alerts** (weekly, by thesis).
- **Fundraising rounds** — a startup can open a round (stage, valuation, ask).

**Jobs**
- **Job offers board** — orgs post jobs. Engagement type is a select (full-time, part-time, contract, internship, volunteer, co-founder, advisor). Salary is free text. Compensation is combinable (salary + equity + stock options + revenue share + other). Location: on-site / hybrid / remote. Jobs expire in 7 days (renewable, one click).

**Admin & infra**
- **Admin panel** (KPIs, pending verifications, users, orgs, connection requests, message reports, site analytics).
- **PWA** (installable, works offline for the shell); Microsoft Entra authentication.

---

## 10. Next Features (roadmap / coming soon)

**Near term**
- **Investment record (bilateral confirmation)** — investor declares "I invested €X in startup Y"; startup confirms "we received €X from Z." Only when **both** confirm is it a verified fact. Builds round progress, backer seal, investor portfolio. **Beedero never touches the money or provides the instrument** — it records verified facts.
- **Shareable verified dossier** (PDF) — the verified record to send to a bank, client, or investor.
- **"Feel valued" moments** — weekly reflection ("2 investors viewed you," "your record grew"), verification-as-celebration.
- **Dashboard: credibility ladder made prominent** + "next steps" guidance.

**Mid term (needs local density first)**
- **Find a Co-Founder** — user-level. Familiar mechanic (profiles → mutual interest → match → chat), but verification and local density are the signal, not photos. Matched co-founders can create an org together.
- **Startup jobs marketplace** (deepen the jobs board with applications as mutual interest).
- **Advisors / board** — verified advisory profiles and track record.

**Longer term (needs scale and/or legal clearance)**
- **Benchmarking** with verified data ("am I normal?" — anonymised, k-anonymity).
- **Non-dilutive funding** — eligibility for public grants based on verified facts.
- **Retail / ECSPR investing** — small-ticket rounds (requires regulatory clearance).
- **Native mobile app** (React Native), when density justifies it.

---

## 11. Key Screens to Wireframe (suggested)

For the design tool, the core surfaces:
1. **Landing page** — "The verified record of your startup." Hero, value props, who it's for, CTA.
2. **Sign up / onboarding** — person first, then connect to a startup or start investing.
3. **Personal profile** (`/p/<handle>`) — brand layer + credibility + **timeline** + skills + activity. Public and owner views.
4. **Organization profile** (`/o/<slug>`) — overview, credibility/status, team, products, fundraising, jobs.
5. **Organization dashboard** — bento grid: profile strength, **credibility ladder**, investor insights (who viewed), next steps, posts/activity, share (badge + dossier).
6. **Feed** — posts by type, with reactions/comments (no vanity counters public).
7. **Discover** — find people & organizations; filters (stage, sector, geography, credibility).
8. **Network area** — Connections, pending requests (the "inbox" of first contacts), Following.
9. **Messaging** — conversation list + thread; connection-request-with-note flow.
10. **Investor pipeline** — private kanban (watching → invested).
11. **Jobs board** — list with filters + job detail + post-a-job form.
12. **Credibility / verification** — the ladder, upload flows, status per level.
13. **Notifications** — bell + panel + preferences.
14. **Admin panel** — KPIs, pending verifications, moderation.
15. **Public badge & dossier** — the shareable verified record.

---

## 12. The Feeling to Design For

Every screen should answer, for the user, three questions:
1. **"What do I get now?"** → the verified profile & dossier (value on day one).
2. **"Is anyone seeing me?"** → investor insights, the right people noticing.
3. **"What do I do next?"** → clear guidance, not empty fields.

And the overarching feeling: **the profile is an asset that makes me more valuable to the world — and Beedero is the honest mirror that shows me its worth.** Trust, credibility, and calm confidence — never hype, never vanity.

---

*Note: Beedero is Portugal-first, English-language interface. Built by a small founding team. The brand's strength is focus — it is "LinkedIn for startups," specialised and verified, not a general network trying to be everything.*

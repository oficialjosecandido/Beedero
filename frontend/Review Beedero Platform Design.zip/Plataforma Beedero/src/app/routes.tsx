import { createBrowserRouter, Link } from "react-router";
import { useState, type FormEvent } from "react";
import { ArrowLeft, Clock3, MessageCircle, MoreHorizontal, Search, Send, UserCheck, UserRoundPlus, X } from "lucide-react";
import Landing from "./Landing";
import Legal from "./Legal";
import Pricing from "./Pricing";
import Feed from "./Feed";
import Organisations from "./Organisations";
import Notifications from "./Notifications";
import AppShell, { MessagesSidebar } from "./AppShell";

function Seal() { return <span className="grid h-5 w-5 place-items-center bg-[#f9de4a] text-[9px] font-black text-black [clip-path:polygon(25%_6%,75%_6%,100%_50%,75%_94%,25%_94%,0_50%)]">✓</span>; }

function Dashboard() {
  return (
    <AppShell>
      <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#f9de4a]">Alma Labs · Company record</p>
      <div className="mt-2 flex flex-wrap items-end justify-between gap-4">
        <h1 className="font-serif text-4xl font-black tracking-[-.045em]">Good morning, Marta.</h1>
        <button className="border border-[#f9de4a]/60 px-4 py-2 text-xs font-bold text-[#f9de4a]">View public profile ↗</button>
      </div>
      <div className="mt-8 grid gap-3 sm:grid-cols-3">
        {[["87", "Record score", "5 points this month"], ["12", "Profile views", "3 relevant viewers"], ["4", "New connections", "Since last Monday"]].map(([v, l, n]) => (
          <div key={l} className="border border-white/10 bg-white/[.025] p-5">
            <p className="font-serif text-4xl font-black tracking-[-.06em]">{v}</p>
            <p className="mt-2 text-[10px] font-black uppercase tracking-[.13em] text-white/45">{l}</p>
            <p className="mt-3 text-xs text-emerald-400">↑ {n}</p>
          </div>
        ))}
      </div>
      <div className="mt-6 grid gap-5 xl:grid-cols-[1.35fr_.65fr]">
        <section className="border border-white/10 bg-white/[.025]">
          <div className="flex items-center justify-between border-b border-white/10 p-5">
            <div>
              <p className="font-serif text-2xl font-black">Your credibility ladder</p>
              <p className="mt-1 text-xs text-white/45">A record that compounds over time.</p>
            </div>
            <span className="text-xs font-bold text-[#f9de4a]">3 / 4 complete</span>
          </div>
          <div className="p-5">
            {[["Legal identity", "Registry certificate confirmed", true], ["Compliance", "Tax & social security confirmed", true], ["Certified accounts", "Reviewed Sep 2026", true], ["Live traction", "Connect Stripe to verify", false]].map(([t, d, done]) => (
              <div key={t as string} className="grid grid-cols-[24px_1fr_auto] gap-3 border-b border-white/10 py-4 last:border-0 items-center">
                <Seal />
                <div><b className="text-sm">{t as string}</b><p className="mt-1 text-xs text-white/45">{d as string}</p></div>
                <span className={done ? "text-xs font-bold text-emerald-400" : "border border-[#f9de4a]/50 px-3 py-1 text-xs font-bold text-[#f9de4a]"}>{done ? "Verified" : "Connect"}</span>
              </div>
            ))}
          </div>
        </section>
        <section className="border border-[#f9de4a]/35 bg-[#f9de4a] p-6 text-black">
          <p className="text-[10px] font-black uppercase tracking-[.18em] text-black/55">Next best step</p>
          <h2 className="mt-4 font-serif text-4xl font-black leading-[.92] tracking-[-.06em]">Make your traction visible.</h2>
          <p className="mt-5 text-sm leading-6 text-black/65">Connect your Stripe account and let your record speak with live evidence.</p>
          <button className="mt-8 bg-black px-4 py-3 text-xs font-black text-white">Connect Stripe →</button>
        </section>
      </div>
      <section className="mt-5 border border-white/10 bg-white/[.025] p-5">
        <div className="flex justify-between">
          <h2 className="font-serif text-2xl font-black">Record activity</h2>
          <button className="text-xs font-bold text-[#f9de4a]">View all</button>
        </div>
        <div className="mt-5 grid gap-3 md:grid-cols-3">
          {["Your legal identity was verified", "Joana Silva viewed your profile", "Your monthly record reflection is ready"].map((x, i) => (
            <div className="border-l-2 border-[#f9de4a] pl-3 text-sm text-white/80" key={x}>
              <p>{x}</p>
              <small className="mt-2 block text-xs text-white/35">{i + 1} day{i ? "s" : ""} ago</small>
            </div>
          ))}
        </div>
      </section>
    </AppShell>
  );
}

const directoryEntries = [
  { type: "Organisation", initials: "N", name: "Noma Energy", detail: "Climate infrastructure", meta: "Seed · Porto", location: "Portugal", stage: "Seed", sector: "Climate", tone: "bg-[#2a2f3a]" },
  { type: "Person", initials: "IC", name: "Inês Carvalho", detail: "Partner at Brave Ventures", meta: "Investor · Lisbon", location: "Portugal", stage: "Investor", sector: "Venture", tone: "bg-[#7b697d]" },
  { type: "Organisation", initials: "S", name: "Soma Health", detail: "Digital health", meta: "Pre-seed · Lisbon", location: "Portugal", stage: "Pre-seed", sector: "Health", tone: "bg-[#2a2f3a]" },
  { type: "Person", initials: "TM", name: "Tiago Moura", detail: "Founder at Rooted", meta: "Founder · Porto", location: "Portugal", stage: "Seed", sector: "Software", tone: "bg-[#5e7d70]" },
  { type: "Organisation", initials: "C", name: "Cork AI", detail: "Industrial intelligence", meta: "Seed · Braga", location: "Portugal", stage: "Seed", sector: "AI", tone: "bg-[#2a2f3a]" },
  { type: "Person", initials: "JS", name: "Joana Silva", detail: "Growth lead at Lumo", meta: "Operator · Lisbon", location: "Portugal", stage: "Series A", sector: "Software", tone: "bg-[#68738a]" },
];

function Discover() {
  const [kind, setKind] = useState("Organisations");
  const [location, setLocation] = useState("Portugal");
  const [stage, setStage] = useState("All stages");
  const [sector, setSector] = useState("All sectors");
  const [openFilter, setOpenFilter] = useState<string | null>(null);
  const [moreFiltersOpen, setMoreFiltersOpen] = useState(false);
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const visibleEntries = directoryEntries.filter(entry =>
    ((kind === "People" && entry.type === "Person") || (kind === "Organisations" && entry.type === "Organisation")) &&
    (location === "Anywhere" || entry.location === location) &&
    (stage === "All stages" || entry.stage === stage) &&
    (sector === "All sectors" || entry.sector === sector)
  );
  return (
    <AppShell>
      <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
        <div>
          <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#f9de4a]">Network directory</p>
          <h1 className="mt-2 font-serif text-4xl font-black tracking-[-.045em]">Find the signal.</h1>
        </div>
        <button className="border border-[#f9de4a] px-4 py-2.5 text-xs font-black uppercase text-[#f9de4a]">Saved search</button>
      </div>
      <div className="mb-7 grid gap-2 sm:grid-cols-2 xl:grid-cols-5">
        {[
          { id: "kind", label: "Looking for", value: kind, onChange: setKind, options: ["Organisations", "People"] },
          { id: "location", label: "Location", value: location, onChange: setLocation, options: ["Portugal", "Anywhere", "Lisbon", "Porto", "Braga"] },
          { id: "stage", label: "Stage", value: stage, onChange: setStage, options: ["All stages", "Pre-seed", "Seed", "Series A", "Investor"] },
          { id: "sector", label: "Sector", value: sector, onChange: setSector, options: ["All sectors", "AI", "Climate", "Health", "Software", "Venture"] },
        ].map(filter => <div key={filter.id} className="relative"><button onClick={() => setOpenFilter(openFilter === filter.id ? null : filter.id)} className={`w-full border bg-white/[.02] px-3 pb-2 pt-1.5 text-left transition ${openFilter === filter.id ? "border-[#f9de4a]" : "border-white/15 hover:border-white/30"}`}><span className="block text-[9px] font-black uppercase tracking-[.13em] text-white/35">{filter.label}</span><span className="mt-0.5 flex items-center justify-between gap-3 text-sm font-bold text-white"><span className="truncate">{filter.value}</span><span className="text-[#f9de4a]">⌄</span></span></button>{openFilter === filter.id && <div className="absolute z-20 mt-1 w-full border border-[#f9de4a]/60 bg-[#171a20] p-1 shadow-2xl">{filter.options.map(option => <button key={option} onClick={() => { filter.onChange(option); setOpenFilter(null); }} className={`block w-full px-3 py-2.5 text-left text-sm transition ${filter.value === option ? "bg-[#f9de4a] font-black text-black" : "text-white/70 hover:bg-white/[.07] hover:text-white"}`}>{option}</button>)}</div>}</div>)}
        <button onClick={() => setMoreFiltersOpen(!moreFiltersOpen)} className={`border px-4 py-3 text-sm font-bold transition ${moreFiltersOpen ? "border-[#f9de4a] bg-[#f9de4a] text-black" : "border-white/15 text-white/60 hover:border-white/30 hover:text-white"}`}>+ More filters</button>
      </div>
      {moreFiltersOpen && <div className="mb-6 flex flex-wrap items-center gap-3 border border-white/10 bg-white/[.02] p-4"><p className="mr-2 text-[10px] font-black uppercase tracking-[.14em] text-white/40">More filters</p><button onClick={() => setVerifiedOnly(!verifiedOnly)} className={`border px-3 py-2 text-xs font-bold transition ${verifiedOnly ? "border-[#f9de4a] bg-[#f9de4a] text-black" : "border-white/15 text-white/60"}`}>Verified only {verifiedOnly && "✓"}</button><button className="border border-white/15 px-3 py-2 text-xs font-bold text-white/60">Recently active</button><button className="border border-white/15 px-3 py-2 text-xs font-bold text-white/60">Open to connect</button></div>}
      <p className="mb-4 text-sm text-white/45"><b className="text-white/75">{visibleEntries.length}</b> {kind.toLowerCase()} match your search</p>
      <div className="grid gap-3 md:grid-cols-2">
        {visibleEntries.map(entry => (
          <article key={entry.name} className="group flex items-start gap-4 border border-white/10 bg-white/[.025] p-5 transition hover:border-[#f9de4a]/50">
            <span className={`grid h-12 w-12 shrink-0 place-items-center font-serif text-sm font-black ${entry.tone} ${entry.type === "Organisation" ? "text-2xl [clip-path:polygon(25%_6%,75%_6%,100%_50%,75%_94%,25%_94%,0_50%)]" : "rounded-full"}`}>{entry.initials}</span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2"><h2 className="font-bold text-sm">{entry.name}</h2><Seal /></div>
              <p className="mt-1 text-sm text-white/65">{entry.detail}</p>
              <p className="mt-3 text-xs text-white/40">{entry.meta}</p>
            </div>
            <span className="text-[#f9de4a] opacity-0 transition group-hover:opacity-100">→</span>
          </article>
        ))}
      </div>
      {visibleEntries.length === 0 && <div className="border border-dashed border-white/15 p-8 text-center text-sm text-white/45">No profiles match these filters. Try a wider search.</div>}
    </AppShell>
  );
}

function Network() {
  return (
    <AppShell>
      <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#f9de4a]">Relationships</p>
      <h1 className="mt-2 mb-8 font-serif text-4xl font-black tracking-[-.045em]">Your network.</h1>
      <div className="grid gap-5 xl:grid-cols-[1.15fr_.85fr]">
        <section>
          <h2 className="mb-3 text-sm font-bold text-white/80">Connection requests <span className="ml-2 rounded-full bg-[#f9de4a] px-2 py-0.5 text-xs font-black text-black">2</span></h2>
          {[["Inês Carvalho", "Partner at Brave Ventures", "Your company's verified record caught my attention."], ["Tiago Moura", "Founder at Rooted", "Would love to compare notes on B2B sales."]].map(([n, r, m]) => (
            <article className="mb-3 border border-white/10 bg-white/[.025] p-5" key={n}>
              <div className="flex gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-full bg-[#5f6b80] text-xs font-black">{n.split(" ").map((a: string) => a[0]).join("")}</span>
                <div><b className="text-sm">{n}</b><p className="text-xs text-white/45">{r}</p></div>
              </div>
              <p className="mt-4 border-l-2 border-[#f9de4a] pl-3 text-sm text-white/75">"{m}"</p>
              <div className="mt-5 flex gap-2">
                <button className="bg-[#f9de4a] px-4 py-2 text-xs font-black text-black">Accept</button>
                <button className="border border-white/15 px-4 py-2 text-xs font-bold text-white/65">Not now</button>
              </div>
            </article>
          ))}
        </section>
        <section className="border border-white/10 bg-white/[.025] p-5">
          <h2 className="font-serif text-2xl font-black">Connection principles</h2>
          <p className="mt-4 text-sm leading-6 text-white/60">Beedero keeps attention and trust distinct. Following shapes your feed; connections open a shared relationship and messaging.</p>
          <div className="mt-7 space-y-3 text-xs">
            {[["Your connections", "28"], ["Following", "43"], ["Profile visibility", "Connections"]].map(([k, v]) => (
              <p key={k} className="flex justify-between border-b border-white/10 pb-3 last:border-0"><span className="text-white/45">{k}</span><b className={k === "Profile visibility" ? "text-emerald-400" : ""}>{v}</b></p>
            ))}
          </div>
        </section>
      </div>
    </AppShell>
  );
}

function Messages() {
  type ChatMessage = { body: string; from: "them" | "me"; stamp: string };
  type Conversation = { name: string; initials: string; role: string; unread: boolean; lastActive: string; tone: string; messages: ChatMessage[] };
  const [unreadOnly, setUnreadOnly] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [requests, setRequests] = useState([
    { name: "Leonor Faria", initials: "LF", role: "Founder at Talo Studio", note: "Hi Marta — I saw your work with Alma Labs and would value a quick introduction.", stamp: "Today · 09:18", tone: "bg-[#886c60]" },
    { name: "Rui Mendes", initials: "RM", role: "Angel investor", note: "Your recent update on the Atlas deal was thoughtful. May I send a note?", stamp: "Yesterday · 18:46", tone: "bg-[#586f80]" },
  ]);
  const [conversations, setConversations] = useState<Conversation[]>([
    { name: "Inês Carvalho", initials: "IC", role: "Partner at Brave Ventures", unread: true, lastActive: "Today · 10:32", tone: "bg-[#7b697d]", messages: [
      { body: "Hi Marta — I came across Alma's profile and the record is very clear.", from: "them", stamp: "Today · 10:18" },
      { body: "Thank you, Inês. Happy to share a little more context.", from: "me", stamp: "Today · 10:24" },
      { body: "Great. Would you be open to a 20-minute introduction next week?", from: "them", stamp: "Today · 10:32" },
    ] },
    { name: "Tiago Moura", initials: "TM", role: "Founder at Rooted", unread: true, lastActive: "Yesterday · 17:14", tone: "bg-[#5e7d70]", messages: [
      { body: "Thanks for connecting, Marta.", from: "them", stamp: "Yesterday · 16:58" },
      { body: "Likewise, Tiago — looking forward to swapping notes.", from: "me", stamp: "Yesterday · 17:14" },
    ] },
    { name: "Joana Martins", initials: "JM", role: "Product lead at Noma Energy", unread: false, lastActive: "Monday · 14:08", tone: "bg-[#68738a]", messages: [
      { body: "The deck is ready. I'll send it over before lunch.", from: "them", stamp: "Monday · 13:51" },
      { body: "Perfect — thank you, Joana.", from: "me", stamp: "Monday · 14:08" },
    ] },
    { name: "Alma Labs", initials: "AL", role: "Organisation", unread: false, lastActive: "Friday · 09:41", tone: "bg-[#514f77]", messages: [
      { body: "Your verification renewal is due soon.", from: "them", stamp: "Friday · 09:41" },
    ] },
  ]);
  const unreadCount = conversations.filter(c => c.unread).length;
  const visibleConversations = conversations
    .filter(c => !unreadOnly || c.unread)
    .sort((a, b) => Number(b.unread) - Number(a.unread));
  const active = conversations.find(c => c.name === selected);

  function chooseConversation(name: string) {
    setSelected(name);
    setConversations(items => items.map(item => item.name === name ? { ...item, unread: false } : item));
  }

  function sendMessage(e: FormEvent) {
    e.preventDefault();
    const body = draft.trim();
    if (!body || !selected) return;
    setConversations(items => items.map(item => item.name === selected ? {
      ...item,
      lastActive: "Today · 14:42",
      messages: [...item.messages, { body, from: "me", stamp: "Today · 14:42" }],
    } : item));
    setDraft("");
  }

  return (
    <AppShell>
      <div className="overflow-hidden border border-white/10 bg-[#11151b]">
        {!active ? <>
          <header className="border-b border-white/10 px-5 py-7 sm:px-8 sm:py-9">
            <div className="flex items-center justify-between"><div className="flex items-center gap-3"><MessageCircle size={24} className="text-[#f9de4a]" /><h1 className="font-serif text-3xl font-black tracking-[-.055em] sm:text-4xl">Messages</h1></div><button aria-label="More message options" className="text-white/45 hover:text-white"><MoreHorizontal size={21} /></button></div>
            <label className="mt-7 flex items-center gap-3 border border-white/15 bg-white/[.025] px-4 py-3.5 text-white/35 focus-within:border-white/35"><Search size={18} /><input className="min-w-0 flex-1 bg-transparent text-sm text-white outline-none placeholder:text-white/35" placeholder="Search messages" /></label>
            <div className="mt-5 flex gap-3"><button onClick={() => setUnreadOnly(false)} className={`px-4 py-2.5 text-sm font-bold ${!unreadOnly ? "bg-[#f9de4a] text-black" : "border border-white/15 text-white/60"}`}>All messages</button><button onClick={() => setUnreadOnly(true)} className={`flex items-center gap-2 border px-4 py-2.5 text-sm font-bold ${unreadOnly ? "border-[#f9de4a] bg-[#f9de4a] text-black" : "border-white/15 text-white/60"}`}>Unread <span className={`grid h-5 min-w-5 place-items-center rounded-full text-[10px] ${unreadOnly ? "bg-black text-[#f9de4a]" : "bg-white/10 text-white/65"}`}>{unreadCount}</span></button></div>
          </header>
          <div className="divide-y divide-white/[.07]">
            {visibleConversations.map(c => { const preview = c.messages.at(-1)?.body; return <button key={c.name} onClick={() => chooseConversation(c.name)} className={`relative flex w-full items-center gap-4 px-5 py-4 text-left transition sm:px-8 sm:py-5 ${c.unread ? "bg-white/[.075] hover:bg-white/[.1]" : "hover:bg-white/[.035]"}`}>
              {c.unread && <span className="absolute inset-y-3 left-0 w-0.5 bg-[#f9de4a]" />}<span className={`grid h-12 w-12 shrink-0 place-items-center rounded-full text-sm font-black ${c.tone}`}>{c.initials}</span><span className="min-w-0 flex-1"><span className="flex items-center justify-between gap-3"><b className="truncate text-base">{c.name}</b><small className={`shrink-0 text-xs ${c.unread ? "text-[#f9de4a]" : "text-white/35"}`}>{c.lastActive.split(" · ").at(-1)}</small></span><span className={`mt-1 flex items-center gap-3 text-sm ${c.unread ? "font-semibold text-white/75" : "text-white/40"}`}><span className="truncate">{preview}</span>{c.unread && <i className="h-2.5 w-2.5 shrink-0 rounded-full bg-[#f9de4a]" />}</span></span>
            </button>; })}
            {visibleConversations.length === 0 && <p className="px-5 py-10 text-center text-sm text-white/40">You have no unread messages.</p>}
          </div>
          {requests.length > 0 && <section className="border-t border-white/10 px-5 py-7 sm:px-8"><div className="mb-5 flex items-center justify-between"><h2 className="text-xs font-black uppercase tracking-[.16em] text-white/45">Message requests</h2><span className="rounded-full bg-white/10 px-2 py-1 text-[10px] font-black text-white/65">{requests.length}</span></div><div className="space-y-3">{requests.map(request => <article key={request.name} className="border border-white/15 bg-white/[.02] p-4 sm:p-5"><div className="flex items-start gap-3"><span className={`grid h-10 w-10 shrink-0 place-items-center rounded-full text-xs font-black ${request.tone}`}>{request.initials}</span><div className="min-w-0"><b className="block text-sm">{request.name}</b><p className="text-xs text-white/45">{request.role}</p></div><button onClick={() => setRequests(items => items.filter(item => item.name !== request.name))} className="ml-auto text-white/35 hover:text-white" aria-label={`Dismiss ${request.name}'s request`}><X size={17} /></button></div><p className="mt-4 text-sm leading-6 text-white/65">{request.note}</p><div className="mt-4 flex items-center justify-between"><small className="text-xs text-white/35">{request.stamp}</small><button onClick={() => setRequests(items => items.filter(item => item.name !== request.name))} className="flex items-center gap-1.5 text-sm font-bold text-[#f9de4a]"><UserCheck size={15} /> Accept</button></div></article>)}</div></section>}
        </> : <section className="flex min-h-[calc(100dvh-140px)] flex-col sm:min-h-[620px]">
          <header className="flex items-center gap-3 border-b border-white/10 px-4 py-3 sm:px-6"><button onClick={() => setSelected(null)} className="grid h-9 w-9 place-items-center border border-white/10 text-white/65 hover:border-[#f9de4a] hover:text-[#f9de4a]" aria-label="Back to messages"><ArrowLeft size={17} /></button><span className={`grid h-9 w-9 place-items-center rounded-full text-[10px] font-black ${active.tone}`}>{active.initials}</span><div className="min-w-0"><b className="block truncate text-sm">{active.name}</b><p className="flex items-center gap-1 text-[10px] text-emerald-400"><UserCheck size={11} /> {active.role === "Organisation" ? "Organisation" : "Connection"}</p></div></header>
          <div className="flex-1 space-y-5 px-4 py-6 sm:px-8"><div className="flex items-center gap-3"><span className="h-px flex-1 bg-white/10" /><span className="font-mono text-[10px] text-white/35">{active.messages[0]?.stamp.split(" · ")[0]}</span><span className="h-px flex-1 bg-white/10" /></div>{active.messages.map((message, i) => <div key={`${message.stamp}-${i}`} className={message.from === "me" ? "ml-auto max-w-[86%] sm:max-w-[64%]" : "max-w-[86%] sm:max-w-[64%]"}><p className={`px-4 py-3 text-sm leading-6 ${message.from === "me" ? "bg-[#f9de4a] font-semibold text-black" : "bg-white/[.07] text-white/85"}`}>{message.body}</p><small className={`mt-1 flex items-center gap-1 text-[10px] text-white/35 ${message.from === "me" ? "justify-end" : ""}`}><Clock3 size={10} /> {message.stamp}</small></div>)}</div>
          <form className="sticky bottom-0 border-t border-white/10 bg-[#11151b] p-3 pb-20 sm:p-5 sm:pb-5" onSubmit={sendMessage}><div className="flex gap-2 border border-white/10 bg-white/[.025] p-1.5 focus-within:border-[#f9de4a]/70"><input value={draft} onChange={e => setDraft(e.target.value)} className="min-w-0 flex-1 bg-transparent px-2 py-2.5 text-base outline-none placeholder:text-white/30" placeholder={`Message ${active.name}…`} /><button disabled={!draft.trim()} className="grid h-10 w-10 place-items-center bg-[#f9de4a] text-black disabled:cursor-not-allowed disabled:opacity-35" aria-label="Send message"><Send size={16} /></button></div><p className="mt-2 flex items-center gap-1.5 text-[10px] text-white/30"><UserRoundPlus size={11} /> You are connected — your message will be delivered directly.</p></form>
        </section>}
      </div>
    </AppShell>
  );
}

function Jobs() {
  return (
    <AppShell>
      <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#f9de4a]">Verified startup roles</p>
      <div className="mt-2 mb-8 flex flex-wrap items-end justify-between gap-4">
        <h1 className="font-serif text-4xl font-black tracking-[-.045em]">Opportunities.</h1>
        <button className="bg-[#f9de4a] px-4 py-2.5 text-xs font-black text-black">+ Post a role</button>
      </div>
      <div className="mb-6 flex flex-wrap gap-2">
        {["All roles", "Remote", "Full-time", "Co-founder", "Verified companies"].map(x => (
          <button key={x} className="border border-white/15 px-4 py-2 text-xs font-bold text-white/65 hover:border-white/30 hover:text-white transition">{x}</button>
        ))}
      </div>
      <div className="grid gap-3">
        {[["Senior Product Designer", "Noma Energy", "Lisbon · Hybrid", "€45–60k + equity"], ["Founding Engineer", "Cork AI", "Remote · Portugal", "€55–75k + equity"], ["Head of Growth", "Soma Health", "Lisbon · On-site", "€40–55k + options"]].map(([role, co, place, pay]) => (
          <article key={role} className="flex flex-wrap items-center gap-5 border border-white/10 bg-white/[.025] p-5">
            <Seal />
            <div className="min-w-[200px] flex-1">
              <h2 className="font-bold text-sm">{role}</h2>
              <p className="mt-1 text-sm text-white/55">{co} · <span className="text-emerald-400">Verified</span></p>
            </div>
            <p className="text-sm text-white/55">{place}</p>
            <p className="text-sm text-white/80">{pay}</p>
            <button className="border border-[#f9de4a]/55 px-4 py-2 text-xs font-bold text-[#f9de4a] hover:bg-[#f9de4a]/10 transition">View role</button>
          </article>
        ))}
      </div>
    </AppShell>
  );
}

function Pipeline() {
  const cols = [["Watching", ["Noma Energy", "Lagoa"]], ["Reviewing", ["Soma Health"]], ["Meeting", ["Cork AI", "Pollen Analytics"]], ["Diligence", ["Rooted"]]];
  return (
    <AppShell>
      <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#f9de4a]">Private investor workspace</p>
      <div className="mt-2 mb-8 flex flex-wrap items-end justify-between gap-4">
        <h1 className="font-serif text-4xl font-black tracking-[-.045em]">Pipeline.</h1>
        <button className="bg-[#f9de4a] px-4 py-2.5 text-xs font-black text-black">+ Add company</button>
      </div>
      <div className="overflow-x-auto pb-4">
        <div className="grid min-w-[860px] grid-cols-4 gap-3">
          {cols.map(([name, items]) => (
            <section key={name as string}>
              <div className="mb-3 flex justify-between text-[10px] font-black uppercase tracking-[.15em] text-white/35">
                <span>{name as string}</span><span>{(items as string[]).length}</span>
              </div>
              <div className="min-h-[400px] border border-white/10 bg-white/[.02] p-3">
                {(items as string[]).map((item, i) => (
                  <article key={item} className="mb-3 border border-white/10 bg-white/[.03] p-4">
                    <div className="flex items-center gap-2"><Seal /><b className="text-sm">{item}</b></div>
                    <p className="mt-3 text-xs text-white/40">{i ? "B2B software" : "Climate infrastructure"}</p>
                    <p className="mt-2 font-mono text-[10px] font-black text-[#f9de4a]">RECORD {i ? "82" : "91"}</p>
                  </article>
                ))}
              </div>
            </section>
          ))}
        </div>
      </div>
      <p className="mt-5 text-xs text-white/35">This workspace is private. Founders never see pipeline status.</p>
    </AppShell>
  );
}

function NotFound() {
  return (
    <AppShell>
      <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#f9de4a]">404</p>
      <h1 className="mt-2 mb-8 font-serif text-4xl font-black tracking-[-.045em]">Not found.</h1>
      <Link className="text-xs font-bold text-[#f9de4a]" to="/app">← Back to feed</Link>
    </AppShell>
  );
}

export const router = createBrowserRouter([
  { path: "/", Component: Landing },
  { path: "/pricing", Component: Pricing },
  { path: "/legal/:document", Component: Legal },
  { path: "/app", Component: Feed },
  { path: "/overview", Component: Dashboard },
  { path: "/discover", Component: Discover },
  { path: "/network", Component: Network },
  { path: "/notifications", Component: Notifications },
  { path: "/organisations", Component: Organisations },
  { path: "/messages", Component: Messages },
  { path: "/jobs", Component: Jobs },
  { path: "/pipeline", Component: Pipeline },
  { path: "/profile", Component: Dashboard },
  { path: "*", Component: NotFound },
]);

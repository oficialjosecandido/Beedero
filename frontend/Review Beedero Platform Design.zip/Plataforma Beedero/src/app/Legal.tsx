import { Link, useParams } from "react-router";

const documents = {
  privacy: ["Privacy policy", "How Beedero collects, uses and safeguards personal data."],
  terms: ["Terms of use", "The terms that govern your use of the Beedero network."],
  cookies: ["Cookie policy", "How Beedero uses cookies and similar technologies."],
  imprint: ["Legal information", "Company, contact and regulatory information for Beedero."],
} as const;

export default function Legal() {
  const { document } = useParams();
  const [title, description] = documents[document as keyof typeof documents] ?? documents.privacy;
  return <main className="min-h-screen bg-[#070806] px-5 py-8 text-white sm:px-8"><header className="mx-auto flex max-w-4xl items-center justify-between"><Link className="font-serif text-lg font-black uppercase tracking-[-.06em]" to="/">Beedero</Link><Link className="text-xs font-black uppercase text-[#f9de4a]" to="/">← Back to home</Link></header><article className="mx-auto mt-24 max-w-3xl border-t border-[#f9de4a] pt-8"><p className="text-[10px] font-black uppercase tracking-[.2em] text-[#f9de4a]">Legal</p><h1 className="mt-5 font-serif text-5xl font-black uppercase leading-[.88] tracking-[-.07em] sm:text-7xl">{title}</h1><p className="mt-7 text-lg leading-8 text-white/70">{description}</p><div className="mt-14 border border-[#f9de4a]/30 bg-white/5 p-6 text-sm leading-7 text-white/65"><b className="block text-white">Legal copy pending review</b><p className="mt-3">This route is in place so the required legal documents are reachable from every public page. Replace this draft area with the approved legal text and publication date before launch.</p></div></article></main>;
}

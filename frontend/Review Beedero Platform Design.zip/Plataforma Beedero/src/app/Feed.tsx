import { useRef, useState, type ReactNode, type ChangeEvent } from "react";
import { Building2, CalendarDays, Image, Link2, MessageSquare, Repeat2, Send, ThumbsDown, ThumbsUp, Video, X } from "lucide-react";
import AppShell, { MessagesSidebar } from "./AppShell";
import { Link } from "react-router";

// ─── Types ────────────────────────────────────────────────────────────────────

type Comment = { initials: string; name: string; text: string; time: string };
type PostAuthorKind = "user" | "org";

interface Post {
  id: string;
  kind: PostAuthorKind;
  initials: string;
  name: string;
  role: string;
  time: string;
  text: string;
  image: string | null;
  profileTo: string;
  comments: Comment[];
  shareable: boolean;
  // org-only fields
  orgBadge?: string;
  orgTag?: string;
}

// ─── Data ─────────────────────────────────────────────────────────────────────

const postsData: Post[] = [
  {
    id: "joana-50",
    kind: "user",
    initials: "JM", name: "Joana Martins", role: "Founder at Rooted", time: "42m",
    text: "We just signed our 50th independent retailer. The number is nice — but the real win is that 31 came through other shop owners.",
    image: "50", profileTo: "/profile/joana-martins", shareable: true,
    comments: [
      { initials: "SC", name: "Sofia Costa", text: "Incredible milestone. The network effect you're describing is exactly what makes this model defensible.", time: "38m" },
      { initials: "AN", name: "André Nunes", text: "31 out of 50 through referral? That's a playbook. Would love to hear more about how you incentivised that.", time: "35m" },
      { initials: "PV", name: "Pedro Vale", text: "Congratulations. This is what compounding looks like in the physical world.", time: "20m" },
    ],
  },
  {
    id: "pedro-distribution",
    kind: "user",
    initials: "PV", name: "Pedro Vale", role: "Operator · Growth & GTM", time: "2h",
    text: "The best early-stage distribution strategy is rarely a channel. It's usually a relationship you haven't earned yet.",
    image: null, profileTo: "/profile", shareable: false, comments: [],
  },
  {
    id: "alma-health-opportunity",
    kind: "org",
    initials: "AH", name: "Alma Health", role: "Verified organisation", time: "4h",
    text: "We're looking for a part-time product advisor with experience taking B2B health products from pilot to repeatable revenue.",
    image: null, profileTo: "/organisations", shareable: false, comments: [],
    orgBadge: "Hiring now", orgTag: "Opportunity",
  },
];

const upcomingEvents = [
  { org: "Alma Health", title: "Product & Health Meetup Lisbon", date: "Oct 3", day: "Fri", rsvp: true },
  { org: "Noma Energy", title: "Climate Infrastructure Forum", date: "Oct 11", day: "Sat", rsvp: false },
  { org: "Verve Studio", title: "Design Systems in Practice", date: "Oct 17", day: "Fri", rsvp: false },
];

const POST_MENU = ["Save post", "Copy link", "Report post"];

// ─── Post card variants ───────────────────────────────────────────────────────

function UserPostCard({ post }: { post: Post }) {
  const [feedback, setFeedback] = useState<"useful" | "notUseful" | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [commentsOpen, setCommentsOpen] = useState(post.comments.length > 0);
  const [commentText, setCommentText] = useState("");
  const [extraComments, setExtraComments] = useState<Comment[]>([]);
  const [shareOpen, setShareOpen] = useState(false);
  const allComments = [...post.comments, ...extraComments];

  function submitComment() {
    if (!commentText.trim()) return;
    setExtraComments(p => [...p, { initials: "MP", name: "Marta Pereira", text: commentText.trim(), time: "now" }]);
    setCommentText("");
  }

  return (
    <>
      <article className="border border-white/10 bg-white/[.025]">
        <div className="p-5">
          <header className="flex items-start gap-3">
            <Link to={post.profileTo} className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#5f6b80] text-xs font-black hover:ring-2 hover:ring-white/20 transition">{post.initials}</Link>
            <div className="min-w-0 flex-1">
              <Link to={post.profileTo} className="text-sm font-bold hover:text-white/70 transition">{post.name}</Link>
              <p className="mt-0.5 text-xs text-white/40">{post.role} · {post.time}</p>
            </div>
            <div className="relative">
              <button onClick={() => setMenuOpen(o => !o)} className="grid h-8 w-8 place-items-center text-white/35 hover:text-white transition" aria-label="Post options">
                <svg width="16" height="4" viewBox="0 0 16 4" fill="currentColor"><circle cx="2" cy="2" r="2"/><circle cx="8" cy="2" r="2"/><circle cx="14" cy="2" r="2"/></svg>
              </button>
              {menuOpen && (
                <div className="absolute right-0 top-9 z-20 w-44 border border-white/15 bg-[#1a1d24] py-1 shadow-2xl">
                  {POST_MENU.map(item => (
                    <button key={item} onClick={() => setMenuOpen(false)} className={`block w-full px-4 py-2.5 text-left text-xs hover:bg-white/5 ${item === "Report post" ? "text-red-400" : "text-white/70"}`}>{item}</button>
                  ))}
                </div>
              )}
            </div>
          </header>

          <p className="mt-4 text-[15px] leading-7 text-white/85">{post.text}</p>

          {post.image && (
            <div className="mt-4 grid h-36 place-items-center bg-[#f9de4a] text-black">
              <span className="font-serif text-8xl font-black tracking-[-.08em]">{post.image}</span>
            </div>
          )}

          <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-white/10 pt-4">
            <div className="flex flex-1 flex-wrap gap-3 text-xs font-bold text-white/45">
              <button onClick={() => setFeedback(feedback === "useful" ? null : "useful")} className={`flex items-center gap-1 transition ${feedback === "useful" ? "text-[#f9de4a]" : "hover:text-white"}`}><ThumbsUp size={13} /> Relevant</button>
              <button onClick={() => setFeedback(feedback === "notUseful" ? null : "notUseful")} className={`flex items-center gap-1 transition ${feedback === "notUseful" ? "text-[#f9de4a]" : "hover:text-white"}`}><ThumbsDown size={13} /> Not for me</button>
              <button onClick={() => setCommentsOpen(o => !o)} className={`flex items-center gap-1 transition ${commentsOpen ? "text-[#f9de4a]" : "hover:text-white"}`}>
                <MessageSquare size={13} /> Comment{allComments.length > 0 && <span className="ml-0.5 opacity-50">{allComments.length}</span>}
              </button>
              {post.shareable && (
                <button onClick={() => setShareOpen(true)} className="flex items-center gap-1 hover:text-white transition"><Repeat2 size={13} /> Share</button>
              )}
            </div>
          </div>
        </div>

        {commentsOpen && (
          <div className="border-t border-white/10 bg-white/[.015]">
            {allComments.map((c, i) => (
              <div key={i} className="flex gap-3 border-b border-white/[.06] px-5 py-4">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[#4a5568] text-[10px] font-black">{c.initials}</span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline gap-2"><b className="text-xs">{c.name}</b><small className="text-[10px] text-white/30">{c.time}</small></div>
                  <p className="mt-1 text-sm leading-6 text-white/70">{c.text}</p>
                </div>
              </div>
            ))}
            <div className="flex gap-3 px-5 py-3">
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[#68738a] text-[10px] font-black">MP</span>
              <div className="flex flex-1 items-center gap-2 border border-white/10 bg-white/5 px-3">
                <input value={commentText} onChange={e => setCommentText(e.target.value)} onKeyDown={e => { if (e.key === "Enter") submitComment(); }} className="flex-1 bg-transparent py-2 text-xs outline-none placeholder:text-white/30" placeholder="Add a comment…" />
                <button onClick={submitComment} disabled={!commentText.trim()} className="text-[#f9de4a] disabled:opacity-30"><Send size={13} /></button>
              </div>
            </div>
          </div>
        )}
      </article>
      {shareOpen && <ShareModal post={post} onClose={() => setShareOpen(false)} />}
    </>
  );
}

function OrgPostCard({ post }: { post: Post }) {
  const [feedback, setFeedback] = useState<"useful" | "notUseful" | null>(null);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [extraComments, setExtraComments] = useState<Comment[]>([]);
  const allComments = [...post.comments, ...extraComments];

  function submitComment() {
    if (!commentText.trim()) return;
    setExtraComments(p => [...p, { initials: "MP", name: "Marta Pereira", text: commentText.trim(), time: "now" }]);
    setCommentText("");
  }

  return (
    <article className="border border-[#f9de4a]/20 bg-[#f9de4a]/[.03]">
      {/* org header strip */}
      <div className="flex items-center gap-2 border-b border-[#f9de4a]/15 bg-[#f9de4a]/[.04] px-5 py-2.5">
        <Building2 size={12} className="text-[#f9de4a]" />
        <span className="text-[10px] font-black uppercase tracking-[.14em] text-[#f9de4a]/70">Organisation · {post.orgTag}</span>
        <span className="ml-auto inline-flex items-center gap-1 bg-[#f9de4a] px-2 py-0.5 text-[9px] font-black text-black">✦ {post.orgBadge}</span>
      </div>

      <div className="p-5">
        <header className="flex items-start gap-3">
          <Link to={post.profileTo} className="grid h-10 w-10 shrink-0 place-items-center rounded-sm bg-[#f9de4a] text-xs font-black text-black hover:opacity-80 transition">{post.initials}</Link>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <Link to={post.profileTo} className="text-sm font-bold hover:text-[#f9de4a] transition">{post.name}</Link>
              <span className="grid h-4 w-4 place-items-center bg-[#f9de4a] text-[8px] font-black text-black [clip-path:polygon(25%_6%,75%_6%,100%_50%,75%_94%,25%_94%,0_50%)]">✓</span>
            </div>
            <p className="mt-0.5 text-xs text-white/40">{post.role} · {post.time}</p>
          </div>
        </header>

        <p className="mt-4 text-[15px] leading-7 text-white/85">{post.text}</p>

        <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-[#f9de4a]/15 pt-4">
          <div className="flex flex-1 flex-wrap gap-3 text-xs font-bold text-white/45">
            <button onClick={() => setFeedback(feedback === "useful" ? null : "useful")} className={`flex items-center gap-1 transition ${feedback === "useful" ? "text-[#f9de4a]" : "hover:text-white"}`}><ThumbsUp size={13} /> Relevant</button>
            <button onClick={() => setFeedback(feedback === "notUseful" ? null : "notUseful")} className={`flex items-center gap-1 transition ${feedback === "notUseful" ? "text-[#f9de4a]" : "hover:text-white"}`}><ThumbsDown size={13} /> Not for me</button>
            <button onClick={() => setCommentsOpen(o => !o)} className={`flex items-center gap-1 transition ${commentsOpen ? "text-[#f9de4a]" : "hover:text-white"}`}>
              <MessageSquare size={13} /> Comment{allComments.length > 0 && <span className="ml-0.5 opacity-50">{allComments.length}</span>}
            </button>
          </div>
          <button className="border border-[#f9de4a]/50 px-3 py-1.5 text-[10px] font-black text-[#f9de4a] hover:bg-[#f9de4a]/10 transition">Apply →</button>
        </div>
      </div>

      {commentsOpen && (
        <div className="border-t border-[#f9de4a]/15 bg-white/[.015]">
          {allComments.map((c, i) => (
            <div key={i} className="flex gap-3 border-b border-white/[.06] px-5 py-4">
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[#4a5568] text-[10px] font-black">{c.initials}</span>
              <div><div className="flex items-baseline gap-2"><b className="text-xs">{c.name}</b><small className="text-[10px] text-white/30">{c.time}</small></div><p className="mt-1 text-sm leading-6 text-white/70">{c.text}</p></div>
            </div>
          ))}
          <div className="flex gap-3 px-5 py-3">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[#68738a] text-[10px] font-black">MP</span>
            <div className="flex flex-1 items-center gap-2 border border-white/10 bg-white/5 px-3">
              <input value={commentText} onChange={e => setCommentText(e.target.value)} onKeyDown={e => { if (e.key === "Enter") submitComment(); }} className="flex-1 bg-transparent py-2 text-xs outline-none placeholder:text-white/30" placeholder="Add a comment…" />
              <button onClick={submitComment} disabled={!commentText.trim()} className="text-[#f9de4a] disabled:opacity-30"><Send size={13} /></button>
            </div>
          </div>
        </div>
      )}
    </article>
  );
}

function PostCard({ post }: { post: Post }) {
  return post.kind === "org" ? <OrgPostCard post={post} /> : <UserPostCard post={post} />;
}

// ─── Share modal ──────────────────────────────────────────────────────────────

function ShareModal({ post, onClose }: { post: Post; onClose: () => void }) {
  const [comment, setComment] = useState("");
  const words = comment.trim() === "" ? 0 : comment.trim().split(/\s+/).length;
  const over = words > 100;
  return (
    <div className="fixed inset-0 z-50 grid place-items-end bg-black/70 backdrop-blur-sm sm:place-items-center sm:p-6" onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <section className="w-full max-w-xl border border-white/15 bg-[#15181f]">
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
          <h2 className="font-serif text-xl font-black tracking-[-.04em]">Share to your feed</h2>
          <button onClick={onClose} className="text-white/45 hover:text-white"><X size={18} /></button>
        </div>
        <div className="p-6">
          <div className="mb-3 flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-[#68738a] text-xs font-black">MP</span>
            <span className="text-sm font-bold">Marta Pereira</span>
            <span className="border border-white/20 bg-white/8 px-2 py-0.5 text-[10px] font-black text-white/55">UPDATE</span>
          </div>
          <textarea value={comment} onChange={e => setComment(e.target.value)} className={`h-20 w-full resize-none border bg-white/5 p-3 text-sm outline-none placeholder:text-white/30 ${over ? "border-red-500/70" : "border-white/10 focus:border-[#f9de4a]"}`} placeholder="Add your take… (optional, max 100 words)" />
          {comment.trim() && <div className={`mt-1 text-right text-[10px] font-bold ${over ? "text-red-400" : words > 80 ? "text-[#f9de4a]" : "text-white/30"}`}>{words} / 100</div>}
          <div className="mt-3 border border-white/15 bg-white/[.02] p-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#5f6b80] text-[9px] font-black">{post.initials}</span>
              <b className="text-xs">{post.name}</b><span className="text-[10px] text-white/35">· {post.role}</span>
            </div>
            <p className="text-xs leading-5 text-white/60 line-clamp-3">{post.text}</p>
          </div>
          <div className="mt-5 flex justify-end gap-3">
            <button onClick={onClose} className="text-xs text-white/40 hover:text-white/60">Cancel</button>
            <button disabled={over} className="flex items-center gap-2 bg-[#f9de4a] px-5 py-2.5 text-xs font-black text-black disabled:opacity-40"><Repeat2 size={13} /> Share update</button>
          </div>
        </div>
      </section>
    </div>
  );
}

// ─── Composer ─────────────────────────────────────────────────────────────────

function Composer({ onClose }: { onClose: () => void }) {
  const [text, setText] = useState("");
  const [mediaMode, setMediaMode] = useState<"photos" | "video" | null>(null);
  const [photos, setPhotos] = useState<string[]>([]);
  const [videoName, setVideoName] = useState<string | null>(null);
  const photoRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLInputElement>(null);
  const words = text.trim() === "" ? 0 : text.trim().split(/\s+/).length;
  const over = words > 100;

  function handlePhotos(e: ChangeEvent<HTMLInputElement>) {
    const urls = Array.from(e.target.files ?? []).slice(0, 5 - photos.length).map(f => URL.createObjectURL(f));
    setPhotos(p => [...p, ...urls].slice(0, 5));
    e.target.value = "";
  }
  function handleVideo(e: ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (f) setVideoName(f.name);
    e.target.value = "";
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-end bg-black/70 backdrop-blur-sm sm:place-items-center sm:p-6" onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <section className="w-full max-w-xl border border-white/15 bg-[#15181f]">
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
          <div>
            <h2 className="font-serif text-2xl font-black tracking-[-.045em]">Make it useful.</h2>
            <p className="mt-0.5 text-xs text-white/40">Share an update with the people who matter.</p>
          </div>
          <button onClick={onClose} className="text-white/45 hover:text-white"><X size={20} /></button>
        </div>
        <div className="p-6">
          <div className="mb-3 flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-[#68738a] text-xs font-black">MP</span>
            <span className="text-sm font-bold">Marta Pereira</span>
            <span className="border border-white/20 bg-white/8 px-2 py-0.5 text-[10px] font-black text-white/55">UPDATE</span>
          </div>
          <textarea value={text} onChange={e => setText(e.target.value)} className={`h-28 w-full resize-none border bg-white/5 p-3 text-sm outline-none placeholder:text-white/30 ${over ? "border-red-500/70" : "border-white/10 focus:border-[#f9de4a]"}`} placeholder="What is worth sharing today? Links go here too — keep it under 100 words." />
          <div className={`mt-1 text-right text-[10px] font-bold ${over ? "text-red-400" : words > 80 ? "text-[#f9de4a]" : "text-white/30"}`}>{words} / 100 words</div>
          <div className="mt-4 flex gap-2 border-t border-white/10 pt-4">
            <button onClick={() => { if (mediaMode === "photos") { setMediaMode(null); setPhotos([]); } else { setMediaMode("photos"); setVideoName(null); photoRef.current?.click(); } }} disabled={mediaMode === "video"} className={`flex items-center gap-1.5 border px-3 py-2 text-xs font-bold transition disabled:opacity-30 ${mediaMode === "photos" ? "border-[#f9de4a] text-[#f9de4a]" : "border-white/15 text-white/55 hover:border-white/30"}`}><Image size={14} /> Photos{photos.length > 0 ? ` (${photos.length}/5)` : ""}</button>
            <button onClick={() => { if (mediaMode === "video") { setMediaMode(null); setVideoName(null); } else { setMediaMode("video"); setPhotos([]); videoRef.current?.click(); } }} disabled={mediaMode === "photos"} className={`flex items-center gap-1.5 border px-3 py-2 text-xs font-bold transition disabled:opacity-30 ${mediaMode === "video" ? "border-[#f9de4a] text-[#f9de4a]" : "border-white/15 text-white/55 hover:border-white/30"}`}><Video size={14} /> Video</button>
            <span className="ml-auto flex items-center gap-1 text-[10px] text-white/25"><Link2 size={11} /> Links go in the text</span>
          </div>
          <input ref={photoRef} type="file" accept="image/*" multiple className="hidden" onChange={handlePhotos} />
          <input ref={videoRef} type="file" accept="video/*" className="hidden" onChange={handleVideo} />
          {photos.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-2">
              {photos.map((src, i) => (
                <div key={i} className="relative"><img src={src} className="h-16 w-16 object-cover border border-white/10" /><button onClick={() => setPhotos(p => p.filter((_, j) => j !== i))} className="absolute -right-1 -top-1 grid h-4 w-4 place-items-center rounded-full bg-black text-white"><X size={9} /></button></div>
              ))}
              {photos.length < 5 && <button onClick={() => photoRef.current?.click()} className="grid h-16 w-16 place-items-center border border-dashed border-white/20 text-xs text-white/30 hover:border-[#f9de4a]/40 transition">+</button>}
            </div>
          )}
          {videoName && (
            <div className="mt-3 flex items-center gap-2 border border-white/10 bg-white/5 px-3 py-2 text-xs text-white/60">
              <Video size={13} className="text-[#f9de4a]" /><span className="flex-1 truncate">{videoName}</span>
              <button onClick={() => { setVideoName(null); setMediaMode(null); }} className="text-white/35 hover:text-white"><X size={13} /></button>
            </div>
          )}
          <div className="mt-5 flex justify-end">
            <button disabled={!text.trim() || over} className="flex items-center gap-2 bg-[#f9de4a] px-5 py-2.5 text-xs font-black text-black disabled:opacity-40 transition"><Send size={13} /> Publish</button>
          </div>
        </div>
      </section>
    </div>
  );
}

// ─── Right sidebar panels ─────────────────────────────────────────────────────

function SuggestedConnections() {
  const suggestions = [["Sofia Costa", "Partner · Atlas Ventures"], ["Loopline", "Climate tech · Porto"], ["André Nunes", "CFO available for advisory"]];
  return (
    <section className="border border-white/10 p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-serif text-base font-black tracking-[-.03em]">Suggested connections</h2>
        <Link to="/discover" className="text-xs font-bold text-[#f9de4a]">See all</Link>
      </div>
      {suggestions.map(([name, meta]) => (
        <div key={name} className="flex items-center gap-3 py-2">
          <span className="grid h-8 w-8 shrink-0 place-items-center bg-white/10 text-[10px] font-black">{name[0]}</span>
          <span className="min-w-0 flex-1"><b className="block truncate text-xs">{name}</b><small className="block truncate text-[11px] text-white/45">{meta}</small></span>
          <button className="shrink-0 text-[#f9de4a] text-sm font-black hover:opacity-70 transition">+</button>
        </div>
      ))}
    </section>
  );
}

function EventsCalendar() {
  const [rsvped, setRsvped] = useState<Record<number, boolean>>({ 0: true });

  return (
    <section className="border border-white/10">
      <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
        <CalendarDays size={14} className="text-[#f9de4a]" />
        <h2 className="font-serif text-base font-black tracking-[-.03em]">Upcoming events</h2>
      </div>
      <div className="divide-y divide-white/[.06]">
        {upcomingEvents.map((ev, i) => (
          <div key={i} className="flex items-start gap-3 px-4 py-3">
            <div className="shrink-0 w-9 text-center">
              <p className="text-[10px] font-black uppercase text-white/35">{ev.day}</p>
              <p className="font-serif text-lg font-black leading-none text-white">{ev.date.split(" ")[1]}</p>
              <p className="text-[9px] text-white/30">{ev.date.split(" ")[0]}</p>
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold leading-snug">{ev.title}</p>
              <p className="mt-0.5 text-[10px] text-white/40">{ev.org}</p>
            </div>
            <button
              onClick={() => setRsvped(r => ({ ...r, [i]: !r[i] }))}
              className={`shrink-0 px-2.5 py-1 text-[9px] font-black uppercase tracking-[.08em] transition ${rsvped[i] ? "bg-[#f9de4a] text-black" : "border border-white/20 text-white/50 hover:border-[#f9de4a]/50 hover:text-[#f9de4a]"}`}
            >
              {rsvped[i] ? "Going ✓" : "RSVP"}
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function Feed() {
  const [composer, setComposer] = useState(false);

  const rightSidebar = (
    <>
      <MessagesSidebar />
      <SuggestedConnections />
      <EventsCalendar />
    </>
  );

  return (
    <AppShell rightSidebar={rightSidebar}>
      <div className="flex items-end justify-between">
        <div>
          <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#f9de4a]">The network, today</p>
          <h1 className="mt-2 font-serif text-4xl font-black tracking-[-.045em]">Good morning, Marta.</h1>
        </div>
        <button onClick={() => setComposer(true)} className="border border-[#f9de4a] bg-[#f9de4a] px-4 py-2.5 text-xs font-black uppercase text-black lg:hidden">+ Post</button>
      </div>
      <button onClick={() => setComposer(true)} className="mt-7 hidden w-full items-center gap-4 border border-white/10 bg-white/[.035] p-4 text-left text-sm text-white/45 transition hover:border-[#f9de4a]/60 lg:flex">
        <span className="grid h-9 w-9 place-items-center rounded-full bg-[#68738a] text-xs font-black text-white">MP</span>
        Share an update with the people who matter…
      </button>
      <div className="mt-5 grid gap-4">
        {postsData.map(post => <PostCard key={post.id} post={post} />)}
      </div>
      {composer && <Composer onClose={() => setComposer(false)} />}
    </AppShell>
  );
}

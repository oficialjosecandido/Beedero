import { useState, type ReactNode } from "react";
import { Bell, BellDot, BriefcaseBusiness, Building2, ChevronRight, CircleUserRound, Home, MessageCircle, Search, Send, UsersRound, X, type LucideIcon } from "lucide-react";
import { Link, useLocation } from "react-router";

export const navItems: { label: string; to: string; Icon: LucideIcon; badge?: string }[] = [
  { label: "Home", to: "/app", Icon: Home },
  { label: "Discover", to: "/discover", Icon: Search },
  { label: "My network", to: "/network", Icon: UsersRound },
  { label: "Notifications", to: "/notifications", Icon: BellDot, badge: "3" },
  { label: "Messages", to: "/messages", Icon: MessageCircle, badge: "2" },
  { label: "Opportunities", to: "/jobs", Icon: BriefcaseBusiness },
  { label: "Investor pipeline", to: "/pipeline", Icon: ChevronRight },
  { label: "My profile", to: "/profile", Icon: CircleUserRound },
];

const conversations = [
  { initials: "SC", name: "Sofia Costa", preview: "Would love to connect on the Atlas deal...", time: "2m", unread: true },
  { initials: "AN", name: "André Nunes", preview: "Thanks for the intro! Let me know if...", time: "18m", unread: true },
  { initials: "JM", name: "Joana Martins", preview: "The deck is ready, I'll send it over.", time: "1h", unread: false },
  { initials: "AL", name: "Alma Labs", preview: "Your verification renewal is due soon.", time: "3h", unread: false },
];

export function MessagesSidebar() {
  const [activeConvo, setActiveConvo] = useState<number | null>(null);
  const [msgInput, setMsgInput] = useState("");
  return (
    <section className="border border-white/10 bg-[#15181f]">
      <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
        <div className="flex items-center gap-2">
          <MessageCircle size={16} className="text-[#f9de4a]" />
          <h2 className="font-serif text-base font-black tracking-[-.03em]">Messages</h2>
          <span className="ml-1 rounded-full bg-[#f9de4a] px-1.5 py-0.5 text-[9px] font-black text-black">2</span>
        </div>
        <Link to="/messages" className="text-[10px] font-bold uppercase tracking-[.12em] text-[#f9de4a]">See all</Link>
      </div>
      <div className="divide-y divide-white/[.07]">
        {conversations.map((c, i) => (
          <button key={c.name} onClick={() => setActiveConvo(activeConvo === i ? null : i)} className={`flex w-full items-start gap-3 px-4 py-3 text-left transition hover:bg-white/[.04] ${activeConvo === i ? "bg-white/[.06]" : ""}`}>
            <span className={`relative grid h-9 w-9 shrink-0 place-items-center rounded-full text-[10px] font-black ${c.unread ? "bg-[#f9de4a] text-black" : "bg-[#5f6b80] text-white"}`}>
              {c.initials}
              {c.unread && <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full border-2 border-[#15181f] bg-[#f9de4a]" />}
            </span>
            <span className="min-w-0 flex-1">
              <span className="flex items-center justify-between">
                <b className={`text-xs ${c.unread ? "text-white" : "text-white/70"}`}>{c.name}</b>
                <small className="text-[10px] text-white/35">{c.time}</small>
              </span>
              <p className={`mt-0.5 truncate text-[11px] ${c.unread ? "font-semibold text-white/80" : "text-white/40"}`}>{c.preview}</p>
            </span>
          </button>
        ))}
      </div>
      {activeConvo !== null && (
        <div className="border-t border-white/10 p-3">
          <div className="mb-2 max-h-28 overflow-y-auto space-y-2">
            <p className="rounded bg-white/5 p-2 text-[11px] text-white/60">{conversations[activeConvo].preview}</p>
          </div>
          <div className="flex gap-2">
            <input value={msgInput} onChange={e => setMsgInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && msgInput.trim()) setMsgInput(""); }} className="flex-1 border border-white/10 bg-white/5 px-3 py-1.5 text-xs outline-none placeholder:text-white/30 focus:border-[#f9de4a]" placeholder="Write a message…" />
            <button onClick={() => setMsgInput("")} className="grid h-8 w-8 place-items-center bg-[#f9de4a] text-black transition hover:opacity-90"><Send size={13} /></button>
          </div>
        </div>
      )}
    </section>
  );
}

interface AppShellProps {
  children: ReactNode;
  rightSidebar?: ReactNode;
}

export default function AppShell({ children, rightSidebar }: AppShellProps) {
  const { pathname } = useLocation();
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  return (
    <main className="min-h-screen bg-[#111319] text-[#f4f4f1]">
      <header className="sticky top-0 z-30 border-b border-white/10 bg-[#111319]/95 px-4 backdrop-blur sm:px-6">
        <div className="mx-auto flex h-[70px] max-w-[1440px] items-center gap-5">
          <Link className="font-serif text-xl font-black uppercase tracking-[-.055em]" to="/">beedero<span className="text-[#f9de4a]">.</span></Link>
          <label className="hidden max-w-[390px] flex-1 items-center gap-3 border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white/40 md:flex">
            <Search size={15} />
            <input className="min-w-0 flex-1 bg-transparent outline-none placeholder:text-white/40" placeholder="Search people, organisations, skills…" />
          </label>
          <div className="ml-auto flex items-center gap-3">
            <button onClick={() => setNotificationsOpen(!notificationsOpen)} className="relative grid h-10 w-10 place-items-center border border-white/10 text-white/75 transition hover:border-[#f9de4a]" aria-label="Open notifications">
              <Bell size={18} />
              <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-[#f9de4a]" />
            </button>
            <Link to="/profile" className="grid h-10 w-10 place-items-center rounded-full bg-[#68738a] text-xs font-black">MP</Link>
          </div>
        </div>
      </header>

      {notificationsOpen && (
        <section className="fixed right-4 top-[78px] z-40 w-[330px] border border-white/15 bg-[#171a20] p-4 shadow-2xl">
          <div className="flex items-center justify-between">
            <h2 className="font-serif text-xl font-black">Notifications</h2>
            <button onClick={() => setNotificationsOpen(false)} aria-label="Close notifications"><X size={18} /></button>
          </div>
          {["Inês Carvalho accepted your connection.", "Alma Labs appeared in 6 searches this week.", "Your compliance verification expires in 30 days."].map((note, i) => (
            <div className="flex gap-3 border-t border-white/10 py-4 text-sm" key={note}>
              <BellDot size={16} className={i === 2 ? "text-[#f9de4a]" : "text-white/50"} />
              <span>{note}</span>
            </div>
          ))}
          <Link to="/notifications" className="block pt-2 text-xs font-bold text-[#f9de4a]">View all notifications →</Link>
        </section>
      )}

      <div className={`mx-auto grid max-w-[1440px] gap-6 px-4 py-6 pb-24 sm:px-6 lg:pb-8 ${rightSidebar ? "lg:grid-cols-[222px_minmax(0,630px)_minmax(270px,1fr)]" : "lg:grid-cols-[222px_1fr]"}`}>
        <aside className="hidden lg:block">
          <div className="sticky top-[94px]">
            <nav className="grid gap-1">
              {navItems.map(({ label, to, Icon, badge }) => {
                const isActive = pathname === to || (to === "/profile" && pathname === "/overview");
                return (
                  <Link key={label} to={to} className={`flex items-center gap-3 px-3 py-3 text-sm transition ${isActive ? "bg-[#f9de4a] font-extrabold text-black" : "text-white/65 hover:bg-white/5 hover:text-white"}`}>
                    <Icon size={17} strokeWidth={1.8} />{label}
                    {badge && <span className={`ml-auto rounded-full px-1.5 py-0.5 text-[10px] font-black ${isActive ? "bg-black text-[#f9de4a]" : "bg-[#f9de4a] text-black"}`}>{badge}</span>}
                  </Link>
                );
              })}
            </nav>
            <div className="mt-7 border-t border-white/10 pt-5">
              <p className="px-3 text-[10px] font-black uppercase tracking-[.18em] text-white/35">Your organisations</p>
              <Link to="/organisations" className="mt-3 flex items-center gap-3 px-3 py-2 hover:bg-white/5"><Building2 size={16} className="text-[#f9de4a]" /><span className="flex-1 text-sm font-bold">Alma Labs</span><span className="text-xs text-[#f9de4a]">87</span></Link>
              <Link to="/organisations" className="flex items-center gap-3 px-3 py-2 hover:bg-white/5"><Building2 size={16} className="text-white/40" /><span className="flex-1 text-sm">Verve Studio</span></Link>
              <Link to="/organisations" className="mt-2 flex items-center gap-2 px-3 text-xs font-bold text-[#f9de4a]">Manage organisations <ChevronRight size={14} /></Link>
            </div>
          </div>
        </aside>

        <section className="min-w-0">{children}</section>

        {rightSidebar && <aside className="hidden lg:block"><div className="sticky top-[94px] space-y-4">{rightSidebar}</div></aside>}
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 flex justify-around border-t border-white/10 bg-[#111319]/95 px-2 py-2 backdrop-blur lg:hidden">
        {navItems.filter(item => ["Home", "Discover", "Notifications", "Messages", "My profile"].includes(item.label)).map(({ label, to, Icon, badge }) => (
          <Link key={label} to={to} className={`relative grid min-h-12 place-items-center gap-1 px-2 text-[10px] ${pathname === to ? "text-[#f9de4a]" : "text-white/55"}`}>
            <Icon size={18} />
            {badge && <span className="absolute right-2 top-0 grid h-4 min-w-4 place-items-center rounded-full bg-[#f9de4a] text-[9px] font-black text-black">{badge}</span>}
            {label}
          </Link>
        ))}
      </nav>
    </main>
  );
}

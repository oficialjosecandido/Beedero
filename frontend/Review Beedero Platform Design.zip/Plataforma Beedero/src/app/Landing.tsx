import { useEffect, useState, type ReactNode } from "react";
import { Link } from "react-router";

const people = {
  founders: { tab: "Founders", line: "Build the thing.\nFind your people.", copy: "A profile that turns your progress into introductions, hires and investor conversations.", action: "Build my profile" },
  professionals: { tab: "Professionals", line: "Your next role\nknows your name.", copy: "Put your experience in front of founders and teams looking for exactly what you know.", action: "Show my work" },
  companies: { tab: "Companies", line: "Be worth\nlooking up.", copy: "Give your organisation a credible home for its story, team, jobs and milestones.", action: "Create an organisation" },
  investors: { tab: "Investors", line: "Find the signal\nbefore the noise.", copy: "See the context around the companies and people worth meeting next.", action: "Discover the network" },
};

const benefits = [
  ["01", "Founders", "Get discovered for the work you’re actually doing."],
  ["02", "Professionals", "Turn experience into roles, advisory and board opportunities."],
  ["03", "Companies", "Build a presence your team can grow into."],
  ["04", "Investors", "Meet companies with context, not just a deck."],
] as const;

function Hex({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <span className={`grid place-items-center [clip-path:polygon(25%_6%,75%_6%,100%_50%,75%_94%,25%_94%,0_50%)] ${className}`}>{children}</span>;
}

export default function Landing() {
  const [person, setPerson] = useState<keyof typeof people>("founders");
  const [access, setAccess] = useState<"Public" | "Verified only" | "Private">("Verified only");
  const [showTop, setShowTop] = useState(false);
  const current = people[person];

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 560);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return <main className="min-h-screen overflow-hidden bg-[#070806] text-white selection:bg-[#f9de4a] selection:text-black">
    <header className="relative z-10 mx-auto flex max-w-[1440px] items-center justify-between px-5 pb-5 pt-[max(3rem,env(safe-area-inset-top))] sm:px-8 sm:py-5">
      <Link className="font-serif text-lg font-black uppercase tracking-[-.07em]" to="/">Beedero</Link>
      <nav className="hidden gap-7 text-xs font-bold uppercase text-white/65 md:flex"><a href="#benefits">Benefits</a><a href="#product">How it works</a><Link to="/pricing">Pricing</Link></nav>
      <Link className="rounded-full bg-[#f9de4a] px-5 py-2.5 text-xs font-black uppercase text-black transition hover:bg-white" to="/app">Join</Link>
    </header>

    <section className="relative isolate px-5 pb-20 pt-14 sm:px-8 lg:pb-28 lg:pt-20">
      <div className="absolute left-1/2 top-[-10rem] -z-10 h-[42rem] w-[42rem] -translate-x-1/2 rounded-full bg-[#f9de4a]/20 blur-[110px]" />
      <div className="mx-auto grid max-w-[1440px] gap-10 lg:grid-cols-[1.08fr_.92fr] lg:items-center">
        <div>
          <p className="inline-flex rounded-full border border-white/15 px-4 py-2 text-[10px] font-black uppercase tracking-[.2em] text-[#f9de4a]">The network for people in motion</p>
          <h1 className="mt-8 whitespace-pre-line font-serif text-[clamp(3.15rem,15vw,7.4rem)] font-black uppercase leading-[.88] tracking-[-.052em] sm:mt-7 sm:text-[clamp(3.7rem,7.5vw,7.4rem)] sm:leading-[.84] sm:tracking-[-.065em]">{current.line}</h1>
          <p className="mt-7 max-w-xl text-base leading-7 text-white/70 sm:text-lg sm:leading-8">{current.copy}</p>
          <div className="mt-9 flex flex-wrap gap-3"><Link className="rounded-full bg-[#f9de4a] px-7 py-4 text-sm font-black uppercase text-black transition hover:-translate-y-0.5 hover:bg-white" to="/app">{current.action} →</Link><Link className="rounded-full border border-white/25 px-7 py-4 text-sm font-black uppercase transition hover:bg-white hover:text-black" to="/pricing">It’s free to start</Link></div>
          <p className="mt-5 text-sm text-white/45">Free to join. Built for the next step.</p>
        </div>
        <div className="border border-[#f9de4a]/45 bg-[#f9de4a] p-3 text-black"><div className="bg-[#080907] p-5 text-white sm:p-7"><div className="flex items-center justify-between border-b border-white/10 pb-5"><p className="text-[10px] font-black uppercase tracking-[.2em] text-[#f9de4a]">What brings you here?</p><Hex className="h-10 w-10 bg-[#f9de4a] text-black">↗</Hex></div><div className="mt-4 grid gap-2">{(Object.entries(people) as [keyof typeof people, typeof current][]).map(([key, item], i) => <button key={key} onClick={() => setPerson(key)} className={`grid grid-cols-[35px_1fr_auto] items-center gap-3 border px-4 py-4 text-left transition ${person === key ? "border-[#f9de4a] bg-[#f9de4a] text-black" : "border-white/15 hover:border-[#f9de4a]"}`}><span className="font-serif text-2xl opacity-50">0{i + 1}</span><span><b className="block text-sm font-black uppercase">{item.tab}</b><small className={`mt-1 block text-xs ${person === key ? "text-black/60" : "text-white/50"}`}>{key === "founders" ? "Build · hire · raise" : key === "professionals" ? "Advise · join · contribute" : key === "companies" ? "Tell · attract · grow" : "Find · meet · back"}</small></span><span>{person === key ? "↗" : "+"}</span></button>)}</div></div></div>
      </div>
    </section>

    <section id="benefits" className="border-y border-black bg-[#f9de4a] px-5 py-16 text-black sm:px-8"><div className="mx-auto max-w-[1440px]"><div className="flex flex-wrap items-end justify-between gap-5"><h2 className="max-w-xl font-serif text-4xl font-black uppercase leading-[.84] tracking-[-.075em] sm:text-6xl">One network.<br />Four ways forward.</h2><p className="max-w-sm text-sm font-semibold leading-6">Beedero is where opportunity stops being a lucky accident.</p></div><div className="mt-12 grid border-y border-black/20 sm:grid-cols-2 lg:grid-cols-4">{benefits.map(([number, title, copy]) => <article className="group border-b border-black/20 p-5 last:border-0 sm:border-r sm:[&:nth-child(2)]:border-r-0 lg:border-b-0 lg:[&:nth-child(2)]:border-r lg:[&:nth-child(4)]:border-r-0" key={title}><p className="font-serif text-4xl font-black tracking-[-.08em] text-black/35">{number}</p><h3 className="mt-9 text-lg font-black uppercase tracking-[-.04em]">{title}</h3><p className="mt-3 max-w-[220px] text-sm leading-6 text-black/65">{copy}</p></article>)}</div></div></section>

    <section id="product" className="mx-auto grid max-w-[1440px] gap-12 px-5 py-20 sm:px-8 lg:grid-cols-[.85fr_1.15fr] lg:py-28"><div><p className="text-[10px] font-black uppercase tracking-[.2em] text-[#f9de4a]">Trust, on your terms</p><h2 className="mt-5 font-serif text-5xl font-black uppercase leading-[.84] tracking-[-.075em] sm:text-7xl">Share enough.<br /><span className="text-[#f9de4a]">Keep what matters.</span></h2><p className="mt-7 max-w-md text-base leading-7 text-white/65">Your profile creates opportunity. Your controls make it safe. Every meaningful field has its own audience.</p></div><div className="border border-white/15 bg-white/5 p-5 sm:p-7"><div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-5"><div><p className="text-[10px] font-black uppercase tracking-[.18em] text-[#f9de4a]">Product preview</p><p className="mt-1 text-sm text-white/55">Alma Labs · Monthly revenue</p></div><Hex className="h-12 w-12 bg-[#f9de4a] text-xs font-black text-black">✓</Hex></div><div className="my-6 flex flex-wrap gap-2">{(["Public", "Verified only", "Private"] as const).map(option => <button key={option} onClick={() => setAccess(option)} className={`rounded-full border px-4 py-2.5 text-xs font-black transition ${access === option ? "border-[#f9de4a] bg-[#f9de4a] text-black" : "border-white/20 text-white/65 hover:border-[#f9de4a]"}`}>{option}</button>)}</div><div className="border border-white/15 p-5"><p className="text-[10px] font-bold uppercase tracking-[.16em] text-white/45">Live MRR</p><p className={`mt-3 font-serif text-5xl font-black tracking-[-.07em] ${access === "Private" ? "blur-md select-none" : ""}`}>€84,600</p><p className="mt-5 text-xs text-white/55">Visible to <b className="text-[#f9de4a]">{access === "Public" ? "everyone" : access === "Private" ? "only you" : "approved investors"}</b></p></div><p className="mt-4 text-xs leading-5 text-white/45">Click the audience to see how privacy changes without removing the value of your profile.</p></div></section>

    <section className="bg-[#f9de4a] px-5 py-16 text-black sm:px-8"><div className="mx-auto flex max-w-[1440px] flex-wrap items-end justify-between gap-8"><div><p className="text-[10px] font-black uppercase tracking-[.2em] text-black/55">Your next move starts here</p><h2 className="mt-4 font-serif text-4xl font-black uppercase leading-[.84] tracking-[-.075em] sm:text-6xl">Make yourself<br />easy to find.</h2></div><Link className="rounded-full bg-black px-7 py-4 text-sm font-black uppercase text-white transition hover:bg-white hover:text-black" to="/app">Join Beedero →</Link></div></section>

    <footer className="px-5 py-9 sm:px-8"><div className="mx-auto grid max-w-[1440px] gap-7 sm:grid-cols-[1fr_auto] sm:items-end"><div><p className="font-serif text-lg font-black uppercase tracking-[-.07em]">Beedero</p><p className="mt-2 text-xs text-white/45">A professional network built to move people forward.</p></div><div className="flex flex-wrap gap-x-5 gap-y-3 text-[11px] font-bold uppercase text-white/55"><Link to="/pricing">Pricing</Link><Link to="/legal/privacy">Privacy policy</Link><Link to="/legal/terms">Terms of use</Link><Link to="/legal/cookies">Cookie policy</Link><Link to="/legal/imprint">Legal information</Link></div></div></footer>
    <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Back to top" className={`fixed bottom-5 right-5 z-30 grid h-12 w-12 place-items-center rounded-full border border-[#f9de4a]/70 bg-black text-lg text-[#f9de4a] shadow-xl transition-all ${showTop ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"}`}>↑</button>
  </main>;
}

import { BellDot } from "lucide-react";
import AppShell from "./AppShell";

const notes = [
  { text: "Inês Carvalho accepted your connection.", time: "2m ago", urgent: false },
  { text: "Alma Labs appeared in 6 searches this week.", time: "1h ago", urgent: false },
  { text: "Your compliance verification expires in 30 days.", time: "3h ago", urgent: true },
];

export default function Notifications() {
  return (
    <AppShell>
      <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#f9de4a]">Keep the right pulse</p>
      <h1 className="mt-2 mb-8 font-serif text-4xl font-black tracking-[-.045em]">Notifications.</h1>
      <div className="max-w-2xl">
        {notes.map(({ text, time, urgent }) => (
          <article className="flex gap-4 border-b border-white/10 py-5" key={text}>
            <BellDot className={`mt-0.5 shrink-0 ${urgent ? "text-[#f9de4a]" : "text-white/40"}`} size={18} />
            <div className="flex-1">
              <p className="text-sm leading-6 text-white/80">{text}</p>
              <small className="mt-1 block text-[11px] text-white/35">{time}</small>
            </div>
          </article>
        ))}
      </div>
    </AppShell>
  );
}

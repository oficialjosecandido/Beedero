import { Building2, ChevronRight, Plus } from "lucide-react";
import { Link } from "react-router";
import AppShell from "./AppShell";

const organisations = [
  ["Alma Labs", "Co-founder & CEO", "3 of 4 verification levels", "87"],
  ["Verve Studio", "Product advisor", "Profile active", "—"],
];

export default function Organisations() {
  return (
    <AppShell>
      <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#f9de4a]">Your relationships with organisations</p>
      <div className="mt-2 mb-10 flex flex-wrap items-end justify-between gap-5">
        <h1 className="font-serif text-4xl font-black tracking-[-.045em]">Organisations.</h1>
        <button className="flex items-center gap-2 bg-[#f9de4a] px-5 py-3 text-xs font-black uppercase text-black">
          <Plus size={15} /> Create organisation
        </button>
      </div>
      <div className="grid gap-3">
        {organisations.map(([name, role, status, score]) => (
          <article key={name} className="flex flex-wrap items-center gap-5 border border-white/10 bg-white/[.025] p-6">
            <span className="grid h-12 w-12 place-items-center bg-[#f9de4a] text-black">
              <Building2 size={21} />
            </span>
            <div className="min-w-[200px] flex-1">
              <h2 className="font-serif text-2xl font-black tracking-[-.04em]">{name}</h2>
              <p className="mt-1 text-sm text-white/55">{role}</p>
            </div>
            <p className="text-sm text-white/55">{status}</p>
            <b className="font-serif text-3xl text-[#f9de4a]">{score}</b>
            {name === "Alma Labs" ? <Link to="/organisations/alma-labs" className="flex items-center gap-1 text-xs font-bold text-[#f9de4a]">
              Open <ChevronRight size={15} />
            </Link> : <button className="flex items-center gap-1 text-xs font-bold text-[#f9de4a]">Open <ChevronRight size={15} /></button>}
          </article>
        ))}
      </div>
    </AppShell>
  );
}

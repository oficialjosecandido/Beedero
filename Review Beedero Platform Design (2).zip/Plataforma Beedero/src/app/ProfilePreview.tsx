import { CalendarDays, Globe2, LockKeyhole, Sparkles, UsersRound } from "lucide-react";
import { Link, useParams } from "react-router";
import AppShell from "./AppShell";

const publicExperience = [
  ["Work", "Co-founder & CEO", "Alma Labs", "2022 — Present", "Building a clearer, more trusted way for ambitious organisations to be discovered."],
  ["Project", "Atlas research", "Independent", "2023", "A field study into how verified signals compound professional trust."],
  ["Academic", "MSc, Management", "Nova SBE", "2016 — 2018", "Strategy, organisational behaviour and entrepreneurship."],
];

const publicSkills = [
  ["Strategy", "4 yrs"], ["Leadership", "4 yrs"], ["Fundraising", "3 yrs"], ["Research", "1 yr"], ["Data analysis", "1 yr"], ["Management", "2 yrs"], ["Organisational design", "2 yrs"],
];

const timelineYears = ["Now", "2024", "2023", "2022", "2021", "2020", "2018"];

const timelineBranches = [
  { title: "Co-founder & CEO", organisation: "Alma Labs", range: "2022 — present", status: "Ongoing", column: 2, row: "1 / 5", tone: "border-[#f9de4a]/75", accent: "text-[#f9de4a]", label: "Work" },
  { title: "Angel investor", organisation: "Operator Syndicate", range: "2021 — present", status: "Ongoing", column: 3, row: "1 / 6", tone: "border-violet-300/55", accent: "text-violet-300", label: "Investment" },
  { title: "Lisbon Founder Supper", organisation: "18 Oct · Going", range: "Upcoming", status: "Event", column: 4, row: "1", tone: "border-rose-300/55", accent: "text-rose-300", label: "Event" },
  { title: "Trust by design", organisation: "18 Oct · Roundtable", range: "Upcoming", status: "Event", column: 5, row: "1", tone: "border-rose-300/55", accent: "text-rose-300", label: "Event" },
  { title: "Atlas research", organisation: "Independent", range: "2023", status: "Completed", column: 4, row: "3", tone: "border-emerald-300/45", accent: "text-emerald-300", label: "Project" },
  { title: "Mentor", organisation: "Startup Lisboa", range: "2020 — 2022", status: "Completed", column: 4, row: "4 / 7", tone: "border-sky-300/45", accent: "text-sky-300", label: "Volunteer" },
  { title: "MSc, Management", organisation: "Nova SBE", range: "2016 — 2018", status: "Completed", column: 2, row: "7", tone: "border-white/25", accent: "text-white/60", label: "Academic" },
];

function PublicEventTree() {
  return <section className="mt-5 overflow-hidden border border-white/10 bg-white/[.025] p-6 sm:p-9">
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div><p className="text-[10px] font-black uppercase tracking-[.18em] text-[#f9de4a]">Public story</p><h2 className="mt-2 font-serif text-3xl font-black tracking-[-.04em]">Timeline tree.</h2></div>
      <p className="max-w-[300px] text-sm leading-5 text-white/45">One column per activity. Its height shows exactly how long it lived across the years.</p>
    </div>
    <div className="mt-5 flex flex-wrap gap-x-4 gap-y-2 text-[10px] font-bold"><span className="text-[#f9de4a]">● Work</span><span className="text-violet-300">● Investment</span><span className="text-rose-300">● Event</span><span className="text-emerald-300">● Project</span><span className="text-sky-300">● Volunteer</span><span className="text-white/60">● Academic</span></div>
    <div className="mt-7 overflow-x-auto pb-3">
      <div className="grid min-w-[760px] gap-x-2 gap-y-2" style={{ gridTemplateColumns: "58px repeat(4, minmax(142px, 1fr))", gridTemplateRows: "repeat(7, 88px)" }}>
        {timelineYears.map((year, index) => <div key={year} className="col-start-1 flex items-start justify-end border-t border-white/[.09] pt-2 pr-2" style={{ gridRow: index + 1 }}><span className={`text-xs font-black ${year === "Now" ? "text-[#f9de4a]" : "text-white/40"}`}>{year}</span></div>)}
        {timelineYears.map((year, index) => <div key={`guide-${year}`} className="pointer-events-none col-[2/6] border-t border-white/[.09]" style={{ gridRow: index + 1 }} />)}
        {timelineBranches.map(branch => <article key={branch.title} className={`relative z-10 flex min-w-0 flex-col justify-between border-l-[3px] ${branch.tone} bg-[#15181f] p-3 shadow-[0_8px_18px_rgba(0,0,0,.16)]`} style={{ gridColumn: branch.column, gridRow: branch.row }}>
          <div><div className="flex flex-wrap items-center justify-between gap-1"><p className={`text-[9px] font-black uppercase tracking-[.13em] ${branch.accent}`}>{branch.label}</p><span className={`text-[9px] font-black uppercase tracking-[.1em] ${branch.status === "Completed" ? "text-white/35" : branch.accent}`}>{branch.status}</span></div><h3 className="mt-2 text-xs font-bold leading-5 text-white">{branch.title}</h3><p className="mt-1 text-[10px] font-semibold text-white/50">{branch.organisation}</p></div><p className="border-t border-white/10 pt-2 text-[9px] font-black uppercase tracking-[.1em] text-white/35">{branch.range}</p></article>)}
      </div>
    </div>
    <div className="mt-2 flex items-center gap-2 text-[10px] text-white/40"><Sparkles size={13} className="text-[#f9de4a]" /> The yellow and violet branches are still growing; the other branches finish at their final year.</div>
  </section>;
}

function Preview({ restricted = false }: { restricted?: boolean }) {
  const { group } = useParams();
  const groupName = group ? decodeURIComponent(group).replace(/-/g, " ") : "Restricted group 1";
  const experiences = restricted ? [...publicExperience, ["Investment", "Angel investor", "Operator Syndicate", "2021 — Present", "Backing early teams working on durable tools for real-world work."]] : publicExperience;

  return <AppShell><div className="mx-auto max-w-4xl">
    <div className="flex flex-wrap items-center justify-between gap-3"><Link to="/profile" className="text-xs font-bold text-[#f9de4a]">← Back to my profile</Link><span className={`flex items-center gap-2 border px-3 py-1.5 text-[10px] font-black uppercase tracking-[.14em] ${restricted ? "border-sky-300/50 text-sky-300" : "border-[#f9de4a]/50 text-[#f9de4a]"}`}>{restricted ? <UsersRound size={13} /> : <Globe2 size={13} />}{restricted ? `Restricted · ${groupName}` : "Public profile"}</span></div>
    <section className="mt-5 border border-white/10 bg-white/[.025] p-6 sm:p-9"><div className="flex items-start gap-4"><span className="grid h-16 w-16 place-items-center rounded-full bg-[#68738a] text-xl font-black">MP</span><div><h1 className="font-serif text-4xl font-black tracking-[-.055em]">Marta Pereira</h1><p className="mt-2 text-base text-white/65">Co-founder at Alma Labs</p><p className="mt-1 text-sm text-white/40">Lisbon, Portugal · almalabs.pt</p></div></div><p className="mt-7 max-w-2xl border-l-2 border-[#f9de4a] pl-4 text-sm leading-6 text-white/65">Building more useful, trusted ways for people and organisations to connect.</p></section>
    {!restricted && <PublicEventTree />}
    <section className="mt-5 border border-white/10 bg-white/[.025] p-6 sm:p-9"><div className="flex items-center justify-between"><div><p className="text-[10px] font-black uppercase tracking-[.18em] text-[#f9de4a]">Professional record</p><h2 className="mt-2 font-serif text-3xl font-black">Experience.</h2></div>{restricted && <span className="flex items-center gap-1.5 text-xs text-sky-300"><LockKeyhole size={13} /> Shared with your group</span>}</div><div className="mt-7 space-y-0">{experiences.map(([type, title, organisation, period, detail]) => <article key={title} className="grid grid-cols-[24px_1fr] gap-4 border-b border-white/[.08] py-6 first:pt-0 last:border-0 last:pb-0"><span className="mt-1 h-3 w-3 rounded-full bg-[#f9de4a]" /><div><p className="text-[10px] font-black uppercase tracking-[.14em] text-white/35">{type} · {period}</p><h3 className="mt-1 text-base font-bold">{title}</h3><p className="mt-1 text-sm text-white/55">{organisation}</p><p className="mt-3 text-sm leading-6 text-white/60">{detail}</p></div></article>)}</div><div className="mt-8 border-t border-white/10 pt-6"><p className="text-[10px] font-black uppercase tracking-[.18em] text-[#f9de4a]">Skills & time in practice</p><div className="mt-4 flex flex-wrap gap-2">{publicSkills.map(([skill, duration]) => <span key={skill} className="inline-flex items-center gap-2 border border-[#f9de4a]/30 bg-[#f9de4a]/[.06] px-3 py-2 text-xs font-bold text-white"><span>{skill}</span><span className="border-l border-[#f9de4a]/30 pl-2 text-[10px] font-black uppercase tracking-[.08em] text-[#f9de4a]">{duration}</span></span>)}</div></div></section>
  </div></AppShell>;
}

export function PublicProfilePreview() { return <Preview />; }
export function RestrictedProfilePreview() { return <Preview restricted />; }
